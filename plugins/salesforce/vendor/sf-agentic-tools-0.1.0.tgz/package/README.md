# Salesforce Agentic Tools

Salesforce tools for any harness that can run a process or import JavaScript.
One independent package provides the `sf-tools` JSON CLI and a typed TypeScript SDK.
Both call the same domain implementations in-process; the SDK never shells out to the CLI.

This is an independent extraction of the [SF Pi](https://github.com/salesforce/sf-pi)
standalone CLI proposal at commit `3b204a44`, with Apache-2.0 attribution preserved.
It has no Pi runtime dependency. Versioned distributions are published as GitHub
release assets; see [the release process](docs/releases.md).

[Getting started](docs/getting-started.md) · [CLI reference](docs/cli.md) ·
[SDK reference](docs/sdk.md) · [LLM outputs](docs/outputs.md) · [Harness integration](docs/harness-integration.md) ·
[Code Analyzer, metadata, Agentforce](docs/additional-tools.md) · [Contributing](CONTRIBUTING.md)

## Why this package

Coding agents need Salesforce-aware operations: inspect an LWC, diagnose a Flow,
validate a query, scan code, deploy metadata, build Agentforce agents, run targeted
tests, or discover Data 360 actions. This package
exposes those operations through a consistent tool contract, with JSON schemas,
structured results, and artifact paths.

Use the CLI from a process-capable harness or CI job. Use the SDK from a Node.js
application when you want typed inputs and repeated in-process calls. The harness
continues to own the model, conversation, and approval decisions.

The package also includes the instruction-only
[Salesforce integrations skill](skills/salesforce-integrations/SKILL.md), adapted
from SF Integrate. It guides agents through inbound OAuth, outbound credentials,
and hosted MCP setup with the existing tools. Load it through your harness's skill
mechanism; it adds no executable tool or runtime dependency.

## Build and install

Requires Node.js 22.19 or newer. From this checkout:

```sh
npm ci
npm run build
node dist/cli.js tools list --json
node dist/cli.js call sf_flow --input-file examples/flow-quality.json
```

The first call lists the 21 tools. The second runs local Flow quality-rule discovery
without Salesforce credentials and returns `ok: true` plus an `execution.runFile` path.

For a verified, versioned distribution from a clean, committed checkout:

```sh
npm run release:dist -- --tag v0.1.0
```

Install the resulting tarball globally for the CLI, or into a Node project for the SDK:

```sh
npm install --global ./release/v0.1.0/sf-agentic-tools-0.1.0.tgz
# Or, from your consuming project:
npm install /path/to/sf-agentic-tools-0.1.0.tgz
```

To download a release or consume it from the Zana Salesforce plugin, follow
[Versioned distributions](docs/releases.md). `npm pack` remains available for
local development builds. For authentication and your first org query, follow
[Getting started](docs/getting-started.md).
For a runnable SDK example from this checkout:

```sh
node examples/local-tools.mjs
```

## CLI

```sh
sf-tools tools list --json
sf-tools tools describe sf_lwc --json
sf-tools call sf_lwc --input '{"action":"component.list"}' --workspace /path/to/project
sf-tools call sf_flow --input-file request.json --workspace /path/to/project
printf '%s' '{"action":"quality.rules"}' | sf-tools call sf_flow --input -
```

Discovery requires no credentials. `describe` returns the JSON input schema,
action availability, effect requirements, guidance, and the bundled guide's path.
Every call writes exactly one JSON envelope to stdout; process logs go to stderr.
The default model view is bounded to 24,000 UTF-8 JSON bytes. Use `--output full`
for complete normalized data, or `result read` to retrieve omitted fields from the
saved result without rerunning the operation. See [LLM outputs](docs/outputs.md).

## TypeScript SDK

```ts
import { createSalesforceTools } from "sf-agentic-tools";

const sf = createSalesforceTools({
  workspace: "/path/to/project",
  targetOrg: "sandbox",
});
const outcome = await sf.lwc({
  action: "component.inspect",
  component: "helloWorld",
});

if (outcome.ok) {
  console.log(outcome.data.inspection?.bundle.name, outcome.execution.runFile);
} else {
  console.error(outcome.error.code, outcome.error.message);
}

await sf.call("sf_flow", {
  action: "quality.rules",
  quality_profile: "review",
});
await sf.call("data360_query", {
  action: "action.describe",
  params: { action: "sql.run" },
  output_mode: "inline",
});
```

`sf.soql`, `sf.apex`, `sf.lwc`, and `sf.flow` are typed conveniences for `sf.call`.
`callTool(name, input, options)` is also available without a client. Tool names,
action names (including Data 360 families), input fields, result envelopes, diagnostics, and common domain fields have
TypeScript declarations. Data 360's nested `params` remain dynamic and are checked
by its action dispatcher; consult `action.describe` for action requirements.

Use `sf.invoke(name, unknownInput)` or `executeTool` for tool calls received from a
model. Runtime validation applies to both dynamic and typed calls. Execution failures
return `ok: false`; domain failures retain their structured data, diagnostics, and artifacts.
Send `toModelResult(outcome)` to an LLM; the SDK outcome itself retains all normalized
data returned by the domain. Check `status`: a successful submission can still be
`pending`. No Pi `content`/`details`/card wrapper is part of this public contract.
The SDK does not change the working directory, install process signal handlers,
or redirect the host's console.

## Included tools

| Tools                                                      | Capabilities                                                                               |
| ---------------------------------------------------------- | ------------------------------------------------------------------------------------------ |
| `sf_soql`                                                  | Schema discovery, validation, bounded SOQL/SOSL, query plans, exports                      |
| `sf_apex`                                                  | Local file diagnostics, authoring plans, targeted tests, logs, trace flags, anonymous Apex |
| `sf_lwc`                                                   | Component discovery, inspection, diagnostics, local Jest tests                             |
| `sf_flow`                                                  | Plans, inspection, diagnostics, source-bound fixes, validation, lifecycle, targeted tests  |
| `code_analyzer`                                            | Prerequisite checks, recipes, rule discovery, scans, configuration, report inspection      |
| `sf_metadata`                                              | Inventory, manifests, deployment preview/validation, deploy/retrieve jobs and results      |
| `agentscript_authoring`, `agentscript_preview`             | Local AgentScript authoring and org-backed preview conversations                           |
| `agentscript_eval`, `agentscript_lifecycle`                | Evaluation specs, exact-version release evidence, publication, activation and agent users  |
| `data360_discover`, `data360_connect`, `data360_prepare`   | Discovery, connectivity, ingestion and preparation                                         |
| `data360_harmonize`, `data360_segment`, `data360_activate` | Modeling, mapping, audiences and activation                                                |
| `data360_query`, `data360_semantic`, `data360_observe`     | SQL, semantic resources, tracing and analytics                                             |
| `data360_orchestrate`, `data360_api`                       | Journeys and REST operations                                                               |

The precise contract is generated from the extracted tool definitions on every build.
Browser tools, Slack, Pi UI,
and SOQL locking/tracking execution are outside this version. Data 360 ingestion
authentication works across CLI processes through private workspace/target-scoped
session files. See [Data 360 ingestion](docs/data360-ingestion.md) for the workflow.
Local Apex diagnostics require Java and a supplied language-server JAR; see
[Apex diagnostics](docs/apex-diagnostics.md). Nothing is downloaded automatically.

## Authorization, state and cancellation

Org operations use existing local Salesforce authentication and configuration.
Set `target_org` in input, or `targetOrg` on the SDK client, for a reproducible target.
Local LWC operations, Flow quality rules, Apex plans, Data 360 catalogs, metadata
previews/manifests, and AgentScript compilation can run without an org. Metadata
and remote AgentScript operations require an explicit target. Code Analyzer scans
require the installed Salesforce CLI and Code Analyzer plugin.

Effects require authorization **per call** through `--allow-effects` or
`{ allowEffects: true }`. The invoking harness owns the user's approval decision.
This covers remote writes, source fixes, exports, and code/test execution.
Domain intent flags such as `allow_mutation` or `allow_confirmed`, non-production
restrictions, and source-version checks still apply. Only actions declaring dry-run
support can bypass this gate with `dry_run: true`.

Agentforce preview/evaluation also retain domain artifacts under `.sf-agentic-tools/`
in the selected project; keep calls on a preview session sequential.

Each call gets a private artifact directory and a new `run.json`, under a temporary
root by default. Choose `--artifact-dir` / `artifactDir` for durable storage. For
history, replay, or exports, pass the prior `execution.runFile` as `--resume` / `resume`.
Tool, canonical workspace, tool-specific workspace input, and org must match.
Remote-tool resume requires an explicit org on both calls. Code Analyzer and local
AgentScript authoring can resume without an org. Authorization is checked
again on replay. Concurrent calls have separate state and artifacts; source mutations
are serialized per file within a process. Multiple CLI processes have no shared lock.

`--timeout-ms` / `timeoutMs` defaults to 120000 and accepts 1–3600000. SDK calls accept
an `AbortSignal`; CLI calls handle SIGINT/SIGTERM. Cancellation is cooperative and
cannot undo remote work already submitted. A workspace selects operation context;
it is not an OS sandbox. Existing SOQL exports retain the `.sf-pi/exports/soql` boundary.

| Exit | Meaning                                          |
| ---- | ------------------------------------------------ |
| 0    | Success                                          |
| 2    | Invalid input, workspace, or resume scope        |
| 3    | Unknown or unavailable tool/action               |
| 4    | Authorization required or query effects rejected |
| 5    | Execution or storage failure                     |
| 124  | Timeout                                          |
| 130  | Interrupted                                      |

## Development

```sh
npm test                 # build, CLI/SDK tests, public TypeScript consumer checks
npm run test:package     # install a tarball outside this repo; test CLI, SDK and types
npm run check
npm run format:check
```

See [Contributing](CONTRIBUTING.md) for the development workflow and
[the changelog](CHANGELOG.md) for the current release scope.
The [documentation index](docs/README.md) links to the CLI/SDK references,
troubleshooting, harness integration, and architecture.
Bundled upstream guides explain domain workflows; this README defines the standalone
host contract where those guides refer to Pi behavior. Automated validation is offline;
live Salesforce org workflows have not been verified for this extraction.

## License and provenance

Apache-2.0; see [LICENSE.txt](LICENSE.txt) and [NOTICE](NOTICE).
The extracted source retains upstream file paths, commit provenance, and file hashes.
See [architecture and maintenance](docs/architecture.md) for the extraction process.
This is an independently maintained project, not an official Salesforce product.
