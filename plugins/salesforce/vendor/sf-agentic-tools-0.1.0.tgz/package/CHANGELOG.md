# Changelog

## 0.1.0 — 2026-10-03

Initial standalone release distributed through GitHub release assets. The package
has not been published to an npm registry.

### Added

- Tagged release workflow and identical local release commands: required offline
  checks, installable CLI/SDK/skill tarball, catalog, source manifest, and verified
  checksums; version, clean-source and remote-tag gates prevent accidental drift.
- Pinned-release installation guidance for the Zana Salesforce plugin.
- Instruction-only Salesforce integrations skill adapted from SF Integrate,
  covering inbound OAuth, outbound credentials, and hosted MCP handoff through
  existing tools, with no new runtime tool or Pi dependency.
- Portable local Apex diagnostics through CLI and SDK, with owned LSP lifecycle,
  cancellation, bounded source reads and retained diagnostic ranges.
- Jorje local semantic checks enabled by default, an explicit syntax-only override,
  diagnostic coverage metadata, preserved native warning policy and an opt-in
  local Jorje regression test.
- Offline comparison evidence checks and build/runtime snapshots; Flow grading
  rejects failed diagnosis without findings and mismatched source evidence.
- Durable Data 360 ingestion authentication across CLI calls and SDK clients;
  all 18 previously unavailable ingestion/authentication entries are enabled.
  Private scoped credentials, expiring single-use PKCE, bounded CSV/HTTP I/O,
  cancellation, and host-delivered interactive OAuth URLs.
- `sf-tools` CLI with tool listing, schema discovery, JSON/stdin/file input,
  structured results, and stable exit codes.
- TypeScript SDK with `createSalesforceTools`, typed and dynamic invocation,
  convenience methods for core families, and generated Data 360 action-name types.
- Twenty-one tools: SOQL, Apex, LWC, Flow, eleven Data 360 families, Code Analyzer,
  metadata, and four AgentScript/Agentforce families.
- Metadata selection, manifests, asynchronous retrieve/deploy/validation jobs, and
  org/workspace-bound retrieval results with explicit overwrite handling.
- Portable AgentScript SDK compilation, preview sessions bound to org identity,
  evaluation, publication, and exact-version activation safeguards.
- Code Analyzer prerequisite checks, scans, configuration, report filtering, and
  preservation of failed scanner exits; cancellable subprocess execution.
- Operation-specific verb/mode authorization, array-valued resume scope, and
  file mutation locking for newly created files.
- Shared per-call authorization, cancellation, timeout, artifact, and scoped-resume
  behavior for both entry points.
- Independent packaging with bundled domain guides and registries, upstream
  attribution, source provenance, and no Pi runtime dependency.
- Offline CLI/SDK tests, public consumer type checks, clean-package validation,
  and a Node 22/24 CI workflow.
- Getting-started, CLI, SDK, harness, architecture, and troubleshooting guides;
  contribution instructions and runnable local examples.

### Current limits

- Live-org workflows have not been verified for this extraction.
- ApexGuru, browser/Slack/Pi UI,
  and SOQL locking/tracking execution are outside this version.
- Cancellation is cooperative. Source mutation locks are local to a process.

### Origin

Extracted from the SF Pi standalone CLI proposal at commit
`3b204a44eababb7535da92940b7aaa9f96610125`, based on SF Pi v0.289.0.
See [NOTICE](NOTICE) and [architecture](docs/architecture.md) for attribution
and maintenance details.

### Standalone LLM result contract

- Replace public Pi `content`/`details` envelopes with schema-version-2 structured
  data, diagnostics, artifacts, status, execution metadata, and follow-up suggestions.
- Add bounded CLI model output, SDK `toModelResult`, and saved-result paging through
  `readResult` / `result read`. Preserve full canonical results privately.
- Correct failed Apex test status and distinguish pending remote work. Preserve
  AgentScript repair identifiers and filter unavailable recovery tools.
- Version-2 API migration: see [output migration](docs/outputs.md).
- Centralize action policy and private run storage; bound file reads, validate
  dynamic SDK options and stored results, and clean up interrupted temporary writes.
- Add `resetSalesforceConnections()` for long-lived SDK hosts after local auth,
  alias, or configuration changes. Honor CLI `--output full` on input failures.
