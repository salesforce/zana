# Independent extraction

The starting point is SF Pi's proposed `feat/standalone-tool-cli` change,
commit `3b204a44eababb7535da92940b7aaa9f96610125`, based on v0.289.0. The original
proposal exposed 15 tools through a CLI while retaining Pi adapters in the same repo.
Its typed SDK was a local benchmark, not a public package.

This repository extracts the callable domain graph into `vendor/sf-pi` and builds
an independent package. The original SF Pi checkout is not needed to install, build,
or run it. There is no runtime dependency on the SF Pi npm package or its harness.

```mermaid
flowchart LR
  Process[Process-capable harness] --> CLI[sf-tools CLI]
  Node[JavaScript / TypeScript harness] --> SDK[Typed SDK]
  CLI --> Runtime[Shared invocation runtime]
  SDK --> Runtime
  Runtime --> Domain[Extracted Salesforce domain tools]
  Domain --> Files[Local SFDX project]
  Domain --> APIs[Salesforce APIs]
```

## Responsibilities

| Path                                      | Responsibility                                                                          |
| ----------------------------------------- | --------------------------------------------------------------------------------------- |
| `src/index.ts`, `src/types.ts`            | Public SDK, schema-derived input types, outcomes, typed domain fields                   |
| `src/execute.ts`                          | Validation, effects, timeout/cancellation, invocation state, artifacts and resume       |
| `src/action-policy.ts`                    | Shared action availability and effect-authorization rules                               |
| `src/json-files.ts`, `src/run-storage.ts` | Bounded file reads, scoped resume validation, atomic private JSON writes                |
| `src/connections.ts`                      | Public process-wide Salesforce connection and configuration reset                       |
| `src/cli-main.ts`, `src/cli.ts`           | Process input, JSON output, exit codes, console and signal ownership                    |
| `src/discovery.ts`, `src/catalog.json`    | Static discovery without credentials or domain execution                                |
| `src/registry.ts`                         | Lazy domain loaders                                                                     |
| `vendor/sf-pi`                            | Extracted schemas, domain operations, shared Salesforce connection code                 |
| `assets`                                  | Bundled upstream guides and Data 360 registries                                         |
| `scripts/build.mjs`                       | Generated catalog, bundled ESM entry points, TypeScript declarations, dependency checks |

The SDK snapshots input and call options before asynchronous work. Each invocation
has its own AsyncLocalStorage context, state, AbortController, and private artifact
directory. Source changes are serialized per canonical file inside the process.
Only the CLI redirects logging and installs signal handlers. Transport exceptions
produce a bounded error message; domain evidence remains in normalized results.

Run records retain the proposal's schemaVersion 1 scope checks. Workspace and org
must match before history is restored. Resume and result files are limited to
100 MiB; CLI input files are limited to 8 MiB. File readers enforce the limit before
opening and throughout reading, including growth after the initial size check.
Private JSON writes use exclusive temporary files, atomic rename, and cleanup on
failure or cancellation. No shared implicit conversation state or global
authorization is introduced. Connection caches remain in the extracted Salesforce
connection module and are keyed by workspace and target.

Connections cache the resolved org identity. After changing an org alias or
authentication configuration, await `resetSalesforceConnections()` before making
further calls from a long-lived SDK host. It clears shared connections and the
Salesforce SDK's configuration and alias caches across clients without connecting
to an org. Existing sessions retain their resolved identity. Preview and retrieval
identity checks compare against the resolved connection; they do not independently
refresh cached aliases.

## Instruction-only integration guidance

`skills/salesforce-integrations` adapts only the SF Integrate agent guide and README
from reviewed commit `067e50fbad9d2481f5a2f50cc41d340930239061`.
Source paths are `extensions/sf-integrate/AGENT_GUIDE.md` and
`extensions/sf-integrate/README.md`; attribution and modification notices remain
in the skill and `NOTICE`.

This is a deliberate documentation adaptation: extension action sequences become
workflows over the existing metadata, SOQL, and Apex tools. Pi registration,
Guardrail hooks, TUI prompts, session state, fixed callbacks, and executable
integration code are not imported. Secret population and consent use a supported
secure host or Setup path. The skill does not imply automatic source hashing,
plan-bound authorization, rollback, or an additional callable tool. It ships as
plain files and the harness decides when to load it.

## Maintenance and provenance

`vendor/sf-pi/UPSTREAM.json` records the exact source commit, imported source files,
their upstream SHA-256 hashes, and modified file names. `LICENSE.txt` and `NOTICE`
preserve upstream attribution. The extraction keeps recognizable file paths to make
future source comparison practical.

To deliberately refresh from a reviewed source checkout:

```sh
node scripts/import-upstream.mjs /path/to/sf-pi
node scripts/import-extra-upstream.mjs /path/to/sf-pi
node scripts/import-apex-upstream.mjs /path/to/reviewed-current-sf-pi
npm test
npm run test:package
git diff
```

The import script follows the bundle's runtime dependency graph and TypeScript's
relative type imports. It then applies the small, explicit patches in
`scripts/upstream-patches.json`. It fails when patch anchors change, requiring review.
It trims one Pi presentation module to the shared output-mode type. The remaining
patches resolve strict typing issues and replace host-specific parameter guidance.
Review stale files on a refresh; the script does not delete previously extracted
files automatically. Build and tests never run the importer.

The build regenerates discovery metadata and Data 360 action-name types directly
from tool definitions, adapts Pi-specific prompt guidance for external harnesses, rejects
Pi runtime imports, verifies bundled ESM external dependencies are declared, and
emits full TypeScript declarations. The clean-package test also exercises SOQL's
CommonJS dependencies, which are loaded with `createRequire`.

## Validation boundaries

Tests cover real local LWC/Apex/Flow/Data 360 execution; CLI/SDK result agreement;
invalid inputs, unsupported actions and effect authorization; scoped resume;
parallel artifact isolation; cancellation, timeout and child-process cleanup;
source mutation serialization; storage errors; and public consumer type failures.
A separate test installs the tarball outside this checkout and checks the binary,
SDK, guides, Data 360 assets, SOQL dependencies, and consumer TypeScript declarations.

Remote Salesforce operations retain upstream implementations and are not live-org
certified by these offline tests. The package exposes 21 tools and their declared
available operations. New tests exercise local AgentScript SDK compilation and
metadata generation, scanner failure semantics, subprocess bounds, exact-version
activation gates, and preview/retrieval org scope.

## Additional domain extraction

`scripts/import-extra-upstream.mjs` extracts Code Analyzer schemas/helpers and the
four AgentScript tool graphs from the same recorded upstream commit. It follows
imports after deterministic transformations and applies
`scripts/extra-upstream-patches.json` for strict typing and behavioral corrections.
`UPSTREAM.json` records original hashes and the original path when an extracted
schema has a new filename. Normal builds never need the upstream checkout.

Deliberate divergences from SF Pi:

- Registration functions become schema exports and headless execution functions.
  TUI renderers are omitted; preview reports retain structured JSON evidence.
  Code Analyzer gets an independent adapter around the extracted CLI helpers.
- Pi branch history becomes explicitly scoped invocation state. Standalone
  authoring requires explicit files, preview send/end require explicit identifiers,
  and failure inspection requires a run ID. Domain preview/eval artifacts move
  from Pi/SFDX state directories to `.sf-agentic-tools`.
- Pi settings and quality preferences are replaced by catalog defaults and the
  existing explicit operation inputs. No global Pi settings are read or written.
- Source mutation queues use the shared invocation context, including canonical
  paths for new files. Salesforce connection convenience calls inherit the current
  invocation's workspace and cancellation signal.
- Authoring resolves `verb`/`mode` into an explicit declared capability. Server
  fallback, report writes, source mutation, and local inspection are classified
  separately. Array-valued workspace scope is compared by value when resuming.
  New public schemas reject undeclared top-level fields so internal evaluation
  coordinator inputs cannot be passed through a tool call.
  A compile check with severity-1 diagnostics returns a failed operation while
  preserving its diagnostic evidence; inspection/quality findings remain separate.
- Preview sessions record the Salesforce org identity and check it before reuse.
  Activation/deactivation require an explicit version. Untested activation is
  unavailable. Publication-quality acknowledgments do not persist between calls.
- Code Analyzer preserves nonzero exits and missing-report failures. Reports and
  scan summaries are separate artifacts; raw-report inspection never invents a
  successful scanner exit. Subprocesses use literal arguments, bounded output,
  cancellation, and process-group termination where supported.
- General metadata operations are authored in `src/tools/metadata.ts` using the
  Salesforce source-deploy-retrieve SDK. Retrieval results require job-bound state,
  org identity, output scope, and renewed overwrite/effect authorization.
- SOQL language-server status runs entirely locally. Data 360 action descriptions
  cover the standalone discovery and raw REST actions as well as registry actions.
- Data 360 ingestion replaces module-global maps with individual private session
  files under `.sf-agentic-tools/state/data360`, scoped by canonical workspace and
  explicit target label. Credentials remain separate from run records and results.
  Directory ownership/permissions, symlinks, file size and stored scope are checked.
  PKCE expires after ten minutes and atomic claims allow one exchange per state.
  Tokens expire at the provider deadline, capped at 24 hours; a missing expiry uses
  one hour. Clearing a scope removes both token and pending PKCE records.
- Ingestion HTTP forwards cancellation, rejects redirects and unexpected origins,
  bounds responses to 1 MiB, and bounds workspace-contained CSV uploads to 50 MiB.
  The tenant host comes from the token exchange and cannot be overridden by job
  inputs. Interactive OAuth owns a loopback listener, delivers its URL through a
  host callback (CLI stderr), and closes/cleans up on success, error or cancellation.
  No browser is launched by the library. This portable implementation deliberately
  adapts the extraction's ingestion modules rather than using Pi settings/state.
  These divergences are recorded in `UPSTREAM.json`; review and retain them when
  running the importer, which can replace adapted domain files with upstream code.

The independent adapters are in `src/tools`; the authored portable file/process
bridges are under `vendor/sf-pi/lib/tool-runtime` so extracted imports remain
recognizable. These added bridge files have explicit modification notices. New
bundled guides are standalone-specific rather than copies of Pi UI instructions.

Run both import scripts in order when refreshing. Review behavioral patches and
upstream hash changes before adopting a different base commit. Do not overwrite
local work in the source checkout.

The Apex diagnostics importer is an additional, separately pinned extraction from
SF Pi `403c290e7a93602d2a4bc6b5b264dcbaef37fe14` (v0.292.0). It reads committed
blobs rather than local edits and records original hashes and per-file revisions.
It imports the portable diagnostics result/client and the LSP engine's type/file
helpers. `src/tools/apex.ts` connects them to the shared invocation runtime without
Pi lifecycle dependencies. The action map enables `diagnose.file`; Java/JAR absence
is a runtime prerequisite failure. Adaptations change managed-cache discovery to
`.sf-agentic-tools` and inject bounded, cancellable file reads. Each call owns and
disposes its server. The original result/digest helpers remain internal; normalized
v2 diagnostics preserve codes and ranges. Run this importer after both base importers
when refreshing and review its pinned revision before adopting new upstream code.

The standalone Apex adapter deliberately diverges from SF Pi's inherited
`debug.semantic.errors=false` launcher setting: it enables local semantic checks
by default, with an additive boolean `semantic_checks` input on `diagnose.file`.
The generic LSP engine accepts the owner's setting in both cached/environment
and editor-extension JAR discovery paths; the Apex client owns the default. The
importer replays these changes and retains original upstream hashes. The adapter
waits for Jorje's `indexer/done` notification within the startup deadline before
semantic diagnosis; absence or server exit fails instead of returning premature
cross-file findings. This readiness barrier is also replayed by the importer.
The adapter
preserves native severity, labels warning-only data as warnings, and adds coverage
metadata stating the configured checks, engine response and unfetched org schema.
No result claims full org compilation. This option is added to the standalone
schema without rewriting extracted Apex domain inputs. An opt-in local Jorje test
requires explicit runtime/JAR paths and runs only against an isolated fixture project.

The comparison helpers in `scripts/compare` are developer tooling, excluded from
the package. They freeze build trees, record actual runtime/source identities and
grade source-bound semantic evidence. The offline Flow probe checks both real
findings and a negative transport-failure case. Historical private benchmark
artifacts and scores are never rewritten by these helpers.

`tests/tool-surface.test.ts` verifies every declared action's schema and resolved
capability, rejects unauthorized effects and unavailable actions across all tools,
and checks Data 360 discovery, aliases, endpoint/safety parity, and upstream file
provenance. These checks validate the offline contracts and routing metadata;
remote endpoint behavior still requires explicit live-org verification.
`tests/salesforce-transport.test.ts` exercises the shared connection and HTTP seams
with offline mocks, including API discovery/fallback, scoped caches, bounded query
pagination, continuation-path checks, expired-token refresh, public connection
reset, and cancellation. Storage tests cover file growth, UTF-8 read boundaries,
cancelled writes, private permissions, and exclusive temporary-file ownership.

## Standalone output boundary

`src/results.ts` normalizes the extracted internal envelopes into public
schema-version-2 results. The internal upstream `{content, details}` shape remains
an implementation detail to keep imports maintainable. No Pi display contract is
required by the SDK consumer.

Deliberate divergences:

- Promote semantic digest fields (SOQL query/plan/result, Flow topology) and domain
  details into `data`; remove card icons, rails, duplicated text, skill routing, and
  AgentScript branch events. Branch events remain in private resume state. For
  legacy operations with no equivalent domain object, retain useful rows as labeled
  observations. Raw text is only a fallback error message, never parsed into data.
- Normalize known diagnostics while preserving diagnostic IDs, ranges, fix bindings,
  native severity, and extra fields. Unknown domain fields remain available rather
  than being recursively removed by generic field-name heuristics.
- Respect failing digests even when an upstream Apex helper marked its wrapper
  successful. Distinguish pending Metadata/Apex jobs, retain their IDs, and offer
  scoped status reads. Validate executable recovery hints against tool schemas and
  action availability. Incomplete Data 360 hints become action-discovery suggestions.
- Data 360 executes with internal inline output so its default does not hide semantic
  data behind an upstream file pointer. The standalone layer owns presentation and
  always saves canonical data to `result.json`. Other domain input limits and output
  selection still apply; canonical results do not promise all remote records.
- `src/model-output.ts` projects canonical results into bounded model JSON; it keeps
  errors prominent, treats executable follow-up inputs as atomic, and reports all
  shortening through omission metadata. `src/read-result.ts` reads bounded pages
  from saved canonical results without repeating tool effects. Stored results must
  satisfy the full common schema; model projections are rejected as recovery sources.

CLI calls default to the model view; SDK calls return the full canonical object.
`--output full` is equivalent to the SDK result, including input failures.
Call schema version 2 is independent
of the unchanged discovery catalog version 1 and private resume record version 1.
