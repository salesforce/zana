---
name: salesforce-integrations
description: Plan, configure, and verify Salesforce integration authentication using External Client Apps, Named Credentials, External Credentials, or hosted MCP OAuth. Use for inbound API access or outbound authenticated callouts.
license: Apache-2.0
---

<!-- SPDX-License-Identifier: Apache-2.0 -->

# Salesforce integrations

Adapt SF Integrate's authentication workflows to the tools available in the calling
harness. This skill supplies instructions; it does not register a tool or enforce
plan integrity. `sf_integrate` is not included in sf-agentic-tools.

## Choose the direction

Read only the reference for the requested integration:

- An application authenticating **to Salesforce**: [Inbound OAuth](references/inbound.md).
- Salesforce calling **an external service**: [Outbound credentials](references/outbound.md).
- A client connecting to **Salesforce hosted MCP**: [Hosted MCP OAuth](references/hosted-mcp.md).

## Discover and route

Use the installed schemas, not the upstream extension's action names:

```sh
sf-tools tools describe sf_metadata --json
sf-tools tools describe sf_soql --json
sf-tools tools describe sf_apex --json
```

The SDK equivalents are `describeTool(name)` and `callTool(name, input, options)`.

| Work                                                            | Existing capability                                                   |
| --------------------------------------------------------------- | --------------------------------------------------------------------- |
| Inspect target and queryable prerequisites                      | `sf_soql`: `org.preflight`, `schema.describe`, bounded `query.run`    |
| Inventory metadata and prepare source                           | `sf_metadata`: `inventory`, `manifest`, `deploy.preview`              |
| Check-only validation and deployment                            | `sf_metadata`: `deploy.validate`, `deploy.start`, `deploy.status`     |
| Retrieve non-sensitive configuration for readback               | `sf_metadata`: `retrieve`, `retrieve.status`, `retrieve.result`       |
| Inspect prerequisite Apex or test a callout                     | `sf_apex`: `apex.search`, `apex.source.get`, `anon.run`               |
| Populate credentials, complete consent, configure an MCP client | A verified Salesforce Setup or secure host capability, when available |

The package has no general Salesforce Connect REST client or masked secret prompt.
`data360_api` is scoped to Data 360 and is not a substitute. If a step needs a
capability the harness lacks, finish the source and plan work, then give the exact
Setup task to the operator. Do not claim that step ran.

## Plan, apply, and verify

1. Confirm an explicit target org, its resolved identity and type, API version,
   resource names, and existing resources. Inspect before requesting creation.
   Keep new-resource setup in a sandbox, scratch, developer, or trial org; do not
   mutate a production or unidentified target using this workflow.
2. Prepare a secret-free plan containing the authentication flow, resource graph,
   callback or service URLs, minimal scopes, principal/access assignments, source
   paths, and verification criteria. Record the exact source being reviewed.
   Existing resources require a separately scoped change plan; do not overwrite
   them as part of new-resource setup.
3. Preview locally. Validate deployable metadata against the explicit target
   before deployment. Check that the source, resolved org, and prerequisites still
   match the reviewed plan. Remote validation also requires effects authorization.
   A Connect REST or Setup operation has no universal metadata check-only mode.
4. Apply only the authorized operations. In the CLI, `--allow-effects` grants
   effects for one call; in the SDK, use `{ allowEffects: true }`. Domain intent
   flags are additional requirements. Follow pending jobs to completion and keep
   their identifiers and initiating run files for actions requiring resume.
5. Populate credentials and complete consent through the selected secure path.
   Read back non-sensitive settings and access assignments, then perform the
   flow-specific handshake or bounded callout. After a partial failure or timeout,
   inspect current state before retrying; do not automatically recreate or delete.

Never put secrets, access/refresh tokens, private keys, or secret-bearing URLs in
tool input, chat, source, plans, or logs. Our runtime persists invocation inputs and
results. An environment-variable reference is useful only if the chosen host can
resolve it without echoing or persisting the value. Do not embed secrets in
Anonymous Apex. Global OAuth metadata can contain consumer secrets: use a safe
selected-field inspection or Setup rather than retrieving secret-bearing material
into ordinary package artifacts.

Report evidence separately: metadata validation, resource creation/readback,
credential configuration, consent completion, and a successful handshake/callout.
A created resource, accepted secret, or generated consent URL does not prove the
integration works. Read v2 `ok`, `status`, diagnostics, and domain execution data;
`pending` is not completion. Use saved-result paging for omitted evidence.

## Source

Adapted from Salesforce SF Pi's `extensions/sf-integrate/AGENT_GUIDE.md` and
`README.md` at commit
[`067e50fbad9d2481f5a2f50cc41d340930239061`](https://github.com/salesforce/sf-pi/tree/067e50fbad9d2481f5a2f50cc41d340930239061/extensions/sf-integrate),
under Apache-2.0. Modified for the standalone CLI/SDK: replace extension actions
with existing tool capabilities, omit Pi services, and require the actual client's
callback. No executable SF Integrate implementation is imported.
