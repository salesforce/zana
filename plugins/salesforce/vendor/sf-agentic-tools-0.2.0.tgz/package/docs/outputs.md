# Results for LLMs and applications

Every domain invocation uses the same harness-independent contract. The SDK returns
the complete normalized result. The CLI defaults to a bounded model view; pass
`--output full` for the SDK-equivalent JSON. Neither requires Pi's tool-message format.

```json
{
  "schemaVersion": 2,
  "ok": true,
  "status": "pending",
  "tool": "sf_metadata",
  "action": "deploy.validate",
  "summary": "Validation was submitted; inspect its status before proceeding.",
  "data": {
    "job_id": "0Af000000000001AAA",
    "submitted": true,
    "check_only": true
  },
  "diagnostics": [],
  "nextActions": [],
  "artifacts": [],
  "execution": {
    "runId": "example-run",
    "runFile": "/runs/example-run/run.json",
    "resultFile": "/runs/example-run/result.json"
  }
}
```

The example abbreviates follow-up suggestions and uses illustrative paths. Actual
pending metadata results include a scoped `deploy.status` or `retrieve.status` call.

## Reading a result

| Field         | Meaning                                                                       |
| ------------- | ----------------------------------------------------------------------------- |
| `ok`          | Whether the invocation succeeded; a submitted job can still be pending        |
| `status`      | `success`, `warning`, `pending`, or `error`                                   |
| `summary`     | A short description of the outcome                                            |
| `data`        | Domain fields, with their original field names and structured values          |
| `diagnostics` | Known findings, normalized severity, locations, codes, and repair metadata    |
| `error`       | Failed-call code and message; optional domain error code                      |
| `nextActions` | Instructions or validated tool-call suggestions; never authorization          |
| `artifacts`   | Evidence files such as reports, query exports, manifests, or logs             |
| `execution`   | Run identity, private resume file, and complete normalized result file        |
| `output`      | Present in model views: truncation state, byte ceiling, and omission pointers |

Check `status` before reporting completion. `pending` means an operation was accepted
but its final result is not yet known. `warning` means the operation returned useful
data with concerns; it does not automatically fail an inspection merely because
findings exist. Compiler failures, failed tests, failed scans, and failed completed
deployments retain a failed outcome. Timeouts do not imply remote work stopped.

Diagnostics preserve original ranges and diagnostic/fix identifiers. Normalized
`line` and `column` values are one-based when derived from zero-based AgentScript
ranges. Native severity is retained (`nativeSeverity`, or `ruleSeverity` for Code
Analyzer). Unknown diagnostic variants stay in domain data rather than being lost.

## Bounded model views

```ts
import { createSalesforceTools, toModelResult } from "sf-agentic-tools";

const sf = createSalesforceTools({ workspace: "/project" });
const full = await sf.flow({ action: "quality.rules" });
const forModel = toModelResult(full, { maxBytes: 24000 });
// Return forModel through the harness's tool-result API.
```

Defaults are 24,000 UTF-8 bytes of serialized JSON, 20 items per array preview, and
2,000 characters per string preview. Deep or very wide objects are also bounded.
The byte ceiling covers the envelope and omission metadata; the CLI's final newline
is excluded. Bytes are not model tokens, so tune the ceiling for the harness's budget.

Errors are prioritized in diagnostic previews. Suggested tool-call inputs and file
paths are kept intact or omitted as a whole. Large data is shortened first; reduced
data must not be treated as a complete inventory. `output.omissions` contains JSON
Pointers and reasons (`items`, `string`, `depth`, `budget`); `moreOmissions: true`
means that list was also shortened. A field can have multiple entries as successive
limits are applied. `output.fullResultFile` identifies the complete saved result.

`toModelResult` never modifies the SDK outcome. The complete canonical `result.json`
is stored with mode 0600 in the private run directory before projection. Domain
limits still apply: a query sample remains a sample, and a provider may have already
limited its findings. `output.truncated` describes this projection, not provider
pagination; inspect domain totals, completion flags, and evidence artifacts too.

Use `--output full` when a downstream application needs every canonical field.
Legacy domain `output_mode` inputs remain accepted, but they do not disable the
standalone model byte limit. Data 360 always supplies semantic data to this layer.

## Retrieve omitted data without repeating work

```sh
sf-tools result read /runs/example/result.json --pointer /data/rules --offset 20 --limit 10
sf-tools result read /runs/example/result.json --pointer /diagnostics --limit 5
```

```ts
import { readResult } from "sf-agentic-tools";

const page = await readResult(full.execution!.resultFile, {
  pointer: "/data/rules",
  offset: 20,
  limit: 10,
  maxBytes: 12000,
});
console.log(page.data.value, page.data.nextOffset);
```

`pointer` is a JSON Pointer, defaulting to `/data`. Escape `/` as `~1` and `~` as
`~0` in property names. Arrays are paged by item; strings by UTF-16 character offset.
Pages report `total`, `returned`, and `nextOffset` when another page is available.
If a sequence item cannot fit, `returned` can be zero: request a narrower pointer or
a larger budget rather than advancing the offset. Nested fields can still be
shortened inside a page; its omission pointers refer back to the saved result.

This operation reads canonical result files up to 100 MiB and makes no Salesforce
calls. It validates the complete common result schema and rejects model projections,
resume-state files, missing pointers, and invalid paging arguments.
A harness without direct filesystem access should expose this SDK/CLI helper as a
local tool. Stored result paths are local to the process running the package.

## Migration from the extracted version-1 envelope

The first standalone release uses the version-2 contract, replacing the extracted
version-1 envelope. There is no default legacy wrapper or duplicated Pi rendering
in the public result.

| Previous access                                   | New access                                                           |
| ------------------------------------------------- | -------------------------------------------------------------------- |
| `result.result.details`                           | `result.data` for domain fields                                      |
| `result.result.details.digest.action`             | `result.action`                                                      |
| `result.result.details.digest.artifacts`          | `result.artifacts`                                                   |
| `result.result.content`                           | `result.summary`, `result.error`, and `result.diagnostics`           |
| `result.runFile` / `result.runId`                 | `result.execution.runFile` / `.runId`                                |
| `details.diagnostics`, LWC inspection diagnostics | `result.diagnostics`                                                 |
| SOQL validation findings, Flow findings           | `result.diagnostics`                                                 |
| Code Analyzer `report.run.violations`             | `result.diagnostics`; report counts remain in `data.report`          |
| AgentScript branch events                         | Private resume state; `data.agent_file` identifies the authored file |

Semantic SOQL digest fields (`query`, `validation`, `plan`, `result`,
`schema_preview`) and Flow `topology` are promoted into `data`. Useful legacy rows
without another domain representation become `data.observations`. Rendered card
layout, icons, API rails, skill routing, and duplicate text are omitted.

The private resume record and static discovery catalog keep schema version 1.
Public calls use schema version 2. Common output fields are typed; many
action-specific domain fields still require narrowing. The contract improves LLM
usability without claiming a fully typed schema for every underlying API response.
