# Offline comparison checks

The historical Codex comparison remains private and unchanged. It measured an old
SF Pi extraction CLI, not current native SF Pi. Do not reuse its mutable build paths
or treat its three-case result as current-upstream parity.

After `npm run build`, run a fresh offline Flow contract comparison:

```sh
node scripts/compare/probe.mjs \
  --baseline-build /path/to/sf-pi/packages/cli/dist \
  --baseline-repository /path/to/sf-pi \
  --baseline-label 'reviewed revision; extraction CLI' \
  --baseline-entry sf-pi.js
```

This creates a new ignored `.zcc/benchmarks/offline-comparison-*` directory. It
copies and hashes both build trees, records their real source revisions/worktree
state, hashes package locks and the actual Node executable, and uses identical
fresh Flow fixtures. The snapshot directories must contain all required build
assets. Both arms share the standalone dependencies; the report discloses this
instead of claiming to reproduce historical installations.

The probe calls review rules, file diagnosis and Flow inspection. It preserves raw
responses and SHA-256 hashes, records fixture hashes before and after every call,
matches the returned file and diagnosis source hash, and checks the known duplicate,
missing connector target and undefined
variable independently. Exit 5 counts as diagnosis only when those real findings
exist. A transport-failure/no-findings negative case must fail. Source changes,
response tampering and unrelated evidence also fail the grader. Older `flow.inspect`
responses omit a source hash; those are bound through the unchanged fixture hashes
and exact requested/returned file instead.

`scripts/compare/evidence.mjs` and `snapshot.mjs` are reusable preparation/grading
modules. Build snapshots fail if their destination exists or bytes change during
copying. Runtime dependencies are linked and may change: validate their installation
and lock before model trials. The snapshot records the current machine's Node
binary hash; verify it again if trials run later or on another machine.

No model sessions or org operations are launched by the probe. For a new agent
benchmark, keep identical model/reasoning/prompts, alternate execution order, and
label the actual CLI/package/harness used. Add representative Apex diagnosis,
source-bound repairs, saved-result recovery, local Jest and AgentScript cases rather
than extrapolating this Flow probe. Independent fixture assertions should verify
repairs and behavior; successful tool exits alone do not establish task completion.
