# Local Apex diagnostics

`sf_apex/diagnose.file` is available through the same CLI/SDK dispatcher. It needs
no Salesforce org or effect authorization. Supply `file` or `target`; paths resolve
against the invocation workspace, and an `@` prefix is accepted. Only existing
regular `.cls` and `.trigger` files of at most 4 MiB are accepted.

```sh
sf-tools call sf_apex --input '{"action":"diagnose.file","file":"force-app/main/default/classes/Example.cls"}' --workspace /path/to/project
```

```ts
const result = await sf.apex({
  action: "diagnose.file",
  file: "force-app/main/default/classes/Example.cls",
});
console.log(result.ok, result.diagnostics, result.data.counts);
```

Jorje syntax and local semantic checks are enabled by default. Set
`semantic_checks: false` on `diagnose.file` for syntax-only checks; other actions
reject this option. Existing Apex input fields keep their extracted schemas.

```sh
sf-tools call sf_apex --input '{"action":"diagnose.file","file":"Example.cls","semantic_checks":false}' --workspace /path/to/project
```

Results include `data.coverage` in saved full results and the default model view:

```json
{
  "engine": "jorje",
  "checks": "syntax-and-semantic",
  "orgSchema": "not-fetched",
  "response": "received"
}
```

`checks` records the configured mode (`syntax-only` for an explicit opt-out).
`response` is `unavailable` when the engine cannot return diagnostics. Coverage
does not claim exhaustive compiler validation. The server can use local project
metadata, but this operation never selects an org or retrieves its schema. A clean
result means no findings from those local checks; SOQL fields and missing org
metadata still require deployment compilation or org tests.

Install a compatible Java runtime and obtain a Salesforce Apex language-server
JAR. The package does not download them. Set `SF_LSP_APEX_JAR` or `APEX_LSP_JAR`
to its path. JAR discovery also searches `.sf-agentic-tools/lsp/apex/` in the
workspace hierarchy, `~/.sf-agentic-tools/lsp/apex/`, and installed Salesforce Apex
editor extensions. Select Java using `JAVA_HOME` or `SF_LSP_JAVA`. Java configuration
and JAR compatibility remain the caller's responsibility.

Each invocation owns and disposes its server. Initialization and, for semantic
checks, Jorje's workspace indexing share a 30-second startup deadline. The client
waits for `indexer/done` before semantic diagnosis to avoid false missing-type
findings from a cold index. A missing readiness signal fails the operation.
Diagnosis waits six seconds for a current push response, then attempts a
bounded pull response. Silent, stale, crashed or unavailable servers fail the
operation. A missing response is never treated as a clean file. Shutdown is bounded
and unresponsive processes are killed; cancellation also terminates the process.
The outer invocation timeout bounds the whole operation.

Error findings return `ok: false`, `OPERATION` and CLI exit 5 while retaining their
messages, codes, original ranges and counts. Native warnings retain
`severity: "warning"` and `nativeSeverity: 2`. Warning-only results return
`ok: true`, top-level `status: "warning"`, `data.status: "warning"`, and CLI exit 0.
The tested Jorje JAR emits semantic defects as warnings, including illegal type
assignments. Consumers enforcing a stricter gate should check `status`, warning
counts, or the individual diagnostics rather than only `ok` or the process exit.
Missing prerequisites return failed results with `data.unavailable.detail`; the
action stays declared available. Missing or invalid files return `INPUT`/exit 2.
Full canonical evidence is saved before model projection and is accessible through
`result read` / `readResult`.

Java and the Apex server may create their own project indexes/cache. These local
checks do not replace deployment compilation or org tests. Offline package tests
use deterministic stdio fixtures. A real local Jorje/Java pairing has also verified
semantic findings, valid controls, syntax-only configuration and corrected source.

The local integration test is explicitly opt-in and excluded from `npm test`.
It requires both executable/JAR paths, creates an isolated project, and never
selects an org, fetches credentials or downloads prerequisites:

```sh
SF_LSP_JAVA=/path/to/java SF_LSP_APEX_JAR=/path/to/apex-jorje-lsp.jar npm run test:apex:jorje
```

After building, `node scripts/test-apex-jorje.mjs --report /private/report.json`
can also save fixture hashes, JAR identity and full results for local evidence.
