# Versioned distributions

Releases contain an npm-installable `.tgz`, the standalone discovery catalog,
`release-manifest.json`, and `SHA256SUMS`. The tarball includes compiled `dist/`
ES modules, the CLI, public TypeScript declarations, domain assets/guides, the
integration skill, and license/provenance notices. It has no Pi runtime dependency.
Runtime npm dependencies are installed by the consuming project's package manager;
`node_modules`, credentials, private reports, and workspace state are excluded.
Java and the optional Apex language-server JAR are supplied separately.

## Cut a release

Use a clean checkout with Node.js 22.19 or newer. Update the package and lockfile
versions together with `npm version <version> --no-git-tag-version`, update the
changelog, rebuild generated sources, and commit the release changes. Tags use
exactly `v<package-version>`, including prereleases such as `v0.2.0-rc.1`.

```sh
npm ci
npm run build
# Commit the reviewed version, changelog and generated-source changes first.
npm run release:dist -- --tag v0.1.0
git tag -a v0.1.0 -m 'sf-agentic-tools 0.1.0'
git push origin main
git push origin v0.1.0
```

`release:dist` requires a clean worktree, matching package/lockfile versions and,
if the tag already exists locally, a tag pointing at HEAD. It runs `npm test`,
`npm run check`, `npm run format:check`, and `npm run test:package`, then packages
the verified build into `release/v0.1.0/`. It verifies required package files,
npm integrity, and that verification has not changed the source commit or
tracked/generated sources.
The manifest records the exact source commit, Node requirement, and asset hashes.
An existing version directory is never overwritten; use a fresh checkout to
rebuild. Do not move a published tag or replace published assets. Fixes get a new
version.

Pushing a `v*` tag triggers `.github/workflows/release.yml`. It uses the same
verification/packaging command on Node 22, then publishes the four assets using
the repository's workflow token. Tag/version mismatches and verification failures
stop publication. This requires GitHub Actions, an available `ubuntu-latest` runner,
the GitHub CLI on that runner, and workflow permission to write release contents.
GitHub Enterprise installations can use their supported runner label instead.

When Actions or runners are unavailable, publish the locally verified build using
an authenticated GitHub CLI. Substitute the host/owner/repository of your remote:

```sh
npm run release:publish -- \
  --tag v0.1.0 \
  --repo <github-host>/<owner>/sf-agentic-tools \
  --notes CHANGELOG.md
```

Publishing rechecks every asset's SHA-256, the tarball's npm SHA-512 integrity,
source commit, and remote tag commit. It refuses existing releases and does not
overwrite assets. The CLI uploads to a draft before publication; if publication
is interrupted, inspect that draft and its assets before retrying. A locally
published release's automatic workflow may subsequently fail because the release
already exists; choose one publication route per version.

## Install a pinned release

Private repository assets require authenticated download. Avoid credentials or
expiring asset URLs in `package.json` or a plugin manifest:

```sh
gh release download v0.1.0 \
  --repo <github-host>/<owner>/sf-agentic-tools \
  --dir ./toolkit-release \
  --pattern sf-agentic-tools-0.1.0.tgz \
  --pattern sf-agentic-tools-0.1.0-catalog.json \
  --pattern release-manifest.json \
  --pattern SHA256SUMS
cd toolkit-release
shasum -a 256 -c SHA256SUMS
# From your consuming Node project, install the verified tarball:
npm install /path/to/toolkit-release/sf-agentic-tools-0.1.0.tgz
```

Check the manifest's version and `sourceCommit` against the release tag. On Linux,
`sha256sum -c SHA256SUMS` is equivalent to the macOS `shasum` command above.
The downloaded catalog is useful for inspection; runtime discovery uses the
matching catalog bundled in the package. For the standalone CLI instead:

```sh
npm install --global /path/to/toolkit-release/sf-agentic-tools-0.1.0.tgz
sf-tools tools list --json
```

## Consume from the Zana Salesforce plugin

The release is the independent toolkit distribution; adopting it in the plugin
is a separate integration change. Add the verified tarball to a stable path in
the plugin source, for example `plugins/salesforce/vendor/`, and from that plugin
directory install it as a relative dependency:

```sh
pnpm add ./vendor/sf-agentic-tools-0.1.0.tgz
```

Keep the tarball and resulting lockfile available to plugin CI/packaging, or
publish the package to an approved internal npm registry and pin its version
there. A developer-machine absolute `file:` dependency will not work for other
installations. The plugin's build must include/bundle the runtime dependencies
and toolkit assets; the tarball by itself does not update the plugin installer.

The plugin's Node backend can import `createSalesforceTools`, `listTools`,
`describeTool`, and `toModelResult` from `sf-agentic-tools`. It supplies the
selected workspace and org, handles per-call effect approval, and persists full
results before returning the bounded model projection. Preserve the plugin's
existing context/approval policies when adapting calls. The skill is bundled at
`skills/salesforce-integrations/SKILL.md` relative to the package root (resolve
`sf-agentic-tools/package.json` to locate it); register it through the plugin's
skill mechanism. No Pi code or new `sf_integrate` tool is needed.

See [Harness integration](harness-integration.md) for the invocation contract and
[SDK reference](sdk.md) for typed calls. Downloading or installing this release
does not authorize any live-org operation.
