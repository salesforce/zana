# Code Analyzer, metadata, and Agentforce

These tools are available through both `sf-tools call` and the typed SDK. Use
`tools describe <name> --json` for complete schemas and operation availability.
Examples that execute code, write files, or change an org include per-call effect
authorization. Run live examples only against an org you intend to use.

## Code Analyzer

The `code_analyzer` family supports `doctor`, `recipes`, `rules`, `run`, `config`,
and `last_report`. It invokes the installed Salesforce CLI's Code Analyzer plugin.
Java and Python requirements depend on the selected engines. Nothing installs
prerequisites automatically. ApexGuru and its browser-assisted setup are unavailable.

```sh
sf-tools call code_analyzer --input '{"action":"doctor"}'
sf-tools call code_analyzer --input '{"action":"recipes","output_mode":"inline"}'
sf-tools call code_analyzer --workspace /path/to/project --allow-effects \
  --input '{"action":"run","workspace":["force-app"],"rule_selector":["Recommended"],"severity_threshold":"2"}'
```

Scans, rule discovery, and configuration generation require authorization because
they load engines and workspace configuration, which can execute code. `workspace`
inside this tool's JSON input is an array of paths/globs; the CLI `--workspace` and
SDK `CallOptions.workspace` select the process working directory.

The result retains the scanner exit code, findings, and report path. A nonzero
exit remains a failed operation even when a report exists. A zero exit without
the expected JSON report also fails. Subprocesses have timeouts, bounded output,
and cancellation; arguments are passed without a shell.

Every scan also returns `result.details.summary_file`. Pass that file to
`last_report` to preserve the scan's pass/fail outcome while filtering findings:

```sh
sf-tools call code_analyzer \
  --input '{"action":"last_report","report_file":"/path/from/summary_file","engine":"pmd","severity_threshold":"2"}'
```

A raw Code Analyzer JSON report can also be inspected. Its original process exit
status is unknown, so the result reports `scan_outcome: "unknown"`; successful
inspection does not establish that the scan passed. `report_file` is required.

## Metadata

`sf_metadata` supports local selection and asynchronous Metadata API jobs:

| Action            | Purpose                                                                      |
| ----------------- | ---------------------------------------------------------------------------- |
| `inventory`       | List one to three metadata types in an explicit org                          |
| `manifest`        | Generate `package.xml` from local source, a manifest, or explicit components |
| `deploy.preview`  | Inspect a local deployment selection without connecting                      |
| `deploy.validate` | Submit a check-only deployment, including the requested tests                |
| `deploy.start`    | Submit a deployment with rollback on error                                   |
| `deploy.status`   | Read job status and validation/test failures                                 |
| `retrieve`        | Submit retrieval to a dedicated output directory                             |
| `retrieve.status` | Read retrieval status without returning the ZIP payload                      |
| `retrieve.result` | Download completed retrieval into its bound directory                        |

Source-based deployment requires `source_paths`. An optional `manifest` filters
that source selection. Retrieval and manifest generation can instead take
`metadata: [{"type":"ApexClass","fullName":"Example"}]`. Selections default to
a maximum of 1,000 components; `max_components` can explicitly raise that limit.
Paths stay within the selected workspace, including symlink resolution.

```sh
sf-tools call sf_metadata --workspace /path/to/project \
  --input '{"action":"deploy.preview","source_paths":["force-app"],"manifest":"manifest/package.xml"}'

sf-tools call sf_metadata --workspace /path/to/project --allow-effects \
  --input '{"action":"deploy.validate","source_paths":["force-app"],"target_org":"sandbox","test_level":"RunLocalTests"}'

sf-tools call sf_metadata \
  --input '{"action":"deploy.status","target_org":"sandbox","job_id":"0Af000000000001AAA"}'
```

Replace the sample job ID with the returned `result.details.job_id`. Submission
success means the job was accepted; check status for completion. A completed
failed deployment produces `ok: false`. `RunLocalTests` is the default test level;
`RunSpecifiedTests` requires a nonempty `tests` array.

For retrieval:

```sh
sf-tools call sf_metadata --workspace /path/to/project --allow-effects \
  --input '{"action":"retrieve","target_org":"sandbox","metadata":[{"type":"ApexClass","fullName":"Example"}],"output_dir":"retrieved"}'

sf-tools call sf_metadata --workspace /path/to/project \
  --resume /path/from/retrieval/runFile \
  --input '{"action":"retrieve.status","target_org":"sandbox"}'

sf-tools call sf_metadata --workspace /path/to/project --allow-effects \
  --resume /path/from/retrieval/runFile \
  --input '{"action":"retrieve.result","target_org":"sandbox"}'
```

`retrieve.result` requires the initiating run file (or a subsequent run retaining
that job state). Workspace, target org, org identity, job ID, and output directory
are checked. Existing output files require `overwrite: true` on the result call;
authorization from the submitting call does not carry over. Pending retrievals
return status so callers can retry later. Retrieval writes into the dedicated
directory; it does not merge files into the selected source tree automatically.

`manifest` writes into the invocation's artifact directory by default. An explicit
`output_path` requires effects authorization, and replacing a manifest requires
`overwrite: true`.

## AgentScript authoring

`agentscript_authoring` preserves the upstream `verb` and `mode` contract:

| Verb      | Modes                                                                                                                            |
| --------- | -------------------------------------------------------------------------------------------------------------------------------- |
| `create`  | Scaffold a bundle; omit `mode`                                                                                                   |
| `compile` | `check` (default), `format`                                                                                                      |
| `inspect` | `structure` (default), `context_profile`, `find_references`, `definition`, `check_targets`, `quality`, `review`, `runtime_smoke` |
| `mutate`  | `set_field`, `rename`, `insert`, `delete`, `apply_quick_fix`                                                                     |

Mutation modes retain upstream behavior, including guidance-only responses where
an automatic transformation is not supported. Creation, formatting, mutations,
server compile fallback, runtime smoke, and writing a review report require
effects authorization. Pass `agent_file` explicitly except when creating a bundle.

```sh
sf-tools call agentscript_authoring --workspace /path/to/project --allow-effects \
  --input '{"verb":"create","bundle_name":"Example","template":"minimal"}'

sf-tools call agentscript_authoring --workspace /path/to/project \
  --input '{"verb":"compile","mode":"check","agent_file":"force-app/main/default/aiAuthoringBundles/Example/Example.agent"}'
```

The returned `agent_file` is authoritative if your package directory differs.
Local compilation and inspection use the bundled AgentScript SDK dependencies.
A compile check with blocking diagnostics returns `ok: false` and retains its
diagnostics. Quality/review findings remain distinct from compiler validity.
Pi preferences are not read: preview defaults to `Mock`, evaluation traces to
`failed`, evaluation concurrency to 8, and quality rules to their catalog defaults.
Tool inputs can override the supported preview/evaluation options.

## Agentforce preview, evaluation, and lifecycle

| Tool                    | Actions                                                                                                                  |
| ----------------------- | ------------------------------------------------------------------------------------------------------------------------ |
| `agentscript_preview`   | `start`, `send`, `end`, `end_all`, `trace`, `cleanup`                                                                    |
| `agentscript_eval`      | `generate_spec`, `run`, `run_release`, `get_failure`, `trace`, `resolve_active`                                          |
| `agentscript_lifecycle` | `publish`, `activate`, `deactivate`, `list_versions`, `agent_user_status`, `diagnose_agent_user`, `provision_agent_user` |

Remote actions require an explicit `target_org`, supplied in input or through the
SDK client's `targetOrg`. Preview send/end require `agent_name` and `session_id`.
Sessions retain their org identity; retargeting an alias cannot silently redirect
the next conversation turn. Local artifacts live under `.sf-agentic-tools/agents`
and `.sf-agentic-tools/state/sf-agentscript`. Add `.sf-agentic-tools/` to the
Salesforce project's `.gitignore`.

The release sequence is:

1. Compile and review the local source.
2. Publish an inactive version with `agentscript_lifecycle` / `publish`.
3. Run `agentscript_eval` / `run_release` for that published agent.
4. Activate an explicit version after its exact-org/version release evidence passes.

```ts
const published = await sf.agentLifecycle(
  {
    action: "publish",
    agent_file: "path/to/Example.agent",
    target_org: "sandbox",
  },
  { allowEffects: true },
);
if (!published.ok) throw new Error(published.error.message);

const evaluated = await sf.agentEval(
  {
    action: "run_release",
    agent_file: "path/to/Example.agent",
    agent_api_name: "Example",
    target_org: "sandbox",
  },
  { allowEffects: true, timeoutMs: 900000 },
);
if (!evaluated.ok) throw new Error(evaluated.error.message);

// Use the actual published version from the tool result.
const activated = await sf.agentLifecycle(
  {
    action: "activate",
    agent_api_name: "Example",
    target_org: "sandbox",
    version: 3,
  },
  { allowEffects: true },
);
```

Activation checks persisted release evidence against the org and the selected
BotVersion. `acknowledge_untested_activation: true` is rejected. Publication-quality
risk acknowledgment is scoped to one invocation and never silently reused.
Provisioning agent users retains its upstream `dry_run` contract and requires
effects authorization to make changes.

`cleanup` removes local preview artifacts; `end_all` ends matching preview
sessions. Use `dry_run: true` to inspect either operation. `end_all` still requires
an explicit target org and checks the identities of matching stored sessions.
Keep operations on a single preview session sequential.

Live-org operations have offline contract tests and retain upstream domain logic.
They have not been exercised against a live org in this extraction.
