# CLI reference

The executable is `sf-tools`. From a source checkout after building, use
`node dist/cli.js` in its place.

## Commands

```text
sf-tools --help
sf-tools --version
sf-tools tools list [--json] [--available]
sf-tools tools describe <tool> [--json]
sf-tools call <tool> --input '<json>' [options]
sf-tools call <tool> --input-file <path> [options]
sf-tools call <tool> --input - [options]
sf-tools result read <result-file> [--pointer /data] [--offset 0] [--limit 20]
```

`tools list` returns a compact inventory, using text by default and JSON with
`--json`. All 21 listed tools are exposed; `--available` is accepted for compatibility.
Individual actions may still be unavailable.

`tools describe` always returns JSON containing the exact input schema, action
availability, effect requirements, guidance, `outputSchema`, and the bundled `guidePath`.
An exposed action can still require an org, permissions, or local dependencies.

`call` always returns one JSON envelope on stdout. It does not require `--json`.
Console diagnostics are directed to stderr. `--help` and `--version` return text.

## Call options

| Option                          | Meaning                                                         | Default                              |
| ------------------------------- | --------------------------------------------------------------- | ------------------------------------ |
| `--input <json>`                | JSON object as an argument; use `-` to read stdin               | Required unless using `--input-file` |
| `--input-file <path>`           | Read a JSON object from a file                                  | Required unless using `--input`      |
| `--workspace <path>`            | Existing directory used as the tool's working context           | Current directory                    |
| `--artifact-dir <path>`         | Root for a new private run directory                            | System temporary directory           |
| `--timeout-ms <integer>`        | Invocation timeout, from 1 through 3600000                      | 120000                               |
| `--allow-effects`               | Authorize effects for this invocation                           | Off                                  |
| `--output <mode>`               | `model` for a bounded view; `full` for complete normalized JSON | `model`                              |
| `--max-bytes <integer>`         | Model JSON byte ceiling (4096–1048576)                          | 24000                                |
| `--max-items <integer>`         | Items per array preview (1–1000)                                | 20                                   |
| `--max-string-length <integer>` | Characters per string preview (64–100000)                       | 2000                                 |
| `--resume <run-file>`           | Load compatible state from a prior invocation                   | No previous state                    |

Supply exactly one input source. JSON input is limited to 8 MiB. Put tool arguments
such as `action`, `target_org`, and `quality_profile` inside the JSON object; they
are not CLI flags. Relative input-file paths are resolved from the process's current
directory. `--workspace` selects the domain workspace after input is read.

## Examples

List actions before choosing one:

```sh
sf-tools tools describe sf_flow --json
```

Use stdin to avoid shell quoting for larger payloads:

```sh
sf-tools call sf_flow --input - <<'JSON'
{"action":"quality.rules","quality_profile":"review"}
JSON
```

Inspect a component in a local SFDX project:

```sh
sf-tools call sf_lwc --input '{"action":"component.inspect","component":"helloWorld"}' --workspace /path/to/project
```

After authorizing a targeted test run, include the effect flag:

```sh
sf-tools call sf_lwc --input '{"action":"test.run","component":"helloWorld"}' --workspace /path/to/project --allow-effects
```

The project must have the required LWC Jest runner and tests. Setting the flag does
not install those prerequisites or bypass the tool's domain checks.

## Results and exit codes

Calls use `schemaVersion: 2`: `ok`, `status`, `tool`, `action`, `summary`, `data`,
`diagnostics`, `nextActions`, and `artifacts`. Completed domain invocations also
provide `execution.runId`, `execution.runFile`, and `execution.resultFile`.
Failures include `error.code` / `error.message`; pre-execution errors have no
execution record. Exit 0 with `status: pending` means submission succeeded, not
that the remote job finished.

The default `--output model` adds `output.truncated` and omission pointers, bounded
to `--max-bytes` excluding the terminal newline. `--output full` emits the complete
canonical result without model projection. Both use the same exit status.
See [the output contract](outputs.md) for details.

| Exit | Error code      | Meaning                                                     |
| ---- | --------------- | ----------------------------------------------------------- |
| 0    | —               | Success                                                     |
| 2    | `INPUT`         | Invalid command, input, workspace, timeout, or resume scope |
| 3    | `UNSUPPORTED`   | Unknown or unavailable tool/action                          |
| 4    | `AUTHORIZATION` | Effects require authorization or query effects are rejected |
| 5    | `OPERATION`     | Execution, domain, or storage failure                       |
| 124  | `TIMEOUT`       | Invocation timed out                                        |
| 130  | `INTERRUPTED`   | Invocation was cancelled                                    |

Parse stdout even when the exit code is nonzero. A failed domain operation can return
useful diagnostics and artifacts. SIGINT and SIGTERM cancel the current call;
submitted remote work may continue.

## Artifacts and resume

Keep the `execution.runFile` returned by a call. For example, after an LWC test run:

```sh
sf-tools call sf_lwc --input '{"action":"history.last"}' --workspace /path/to/project --resume /path/to/prior/run.json
```

The tool, canonical workspace, tool-specific workspace input, and target org must
match the previous call. Remote-tool resume requires an explicit `target_org` on both calls. LWC,
Code Analyzer, and local AgentScript authoring can resume without an org. Each resumed call creates a new run file; it does not
overwrite the original. Replay requires authorization again.

See [troubleshooting](troubleshooting.md) for common failures and
[harness integration](harness-integration.md) for process invocation without a shell.

## Read saved results

```sh
sf-tools result read /path/to/result.json --pointer /data/rules --offset 20 --limit 10
sf-tools result read /path/to/result.json --pointer /diagnostics --limit 5
```

This local read never reruns a Salesforce operation. It accepts the model limit flags
and returns `data.value`, with `total`, `returned`, and `nextOffset` for arrays or
strings. Result-file errors use the normal nonzero CLI error envelope. `result read`
is always bounded; use the stored JSON directly when an application needs the entire
file. Input files must be canonical schema-version-2 results of at most 100 MiB.
