# Harness integration

The harness owns conversation, models, approval, and orchestration. This package
owns Salesforce tool discovery, validation, execution, and artifacts.

## Process integration

Any harness capable of launching a process can use the CLI. Discover with
`sf-tools tools list --json`, then request only the tool descriptions relevant to
the task. Pass their `inputSchema` to the harness's tool-registration interface.

Invoke with an argument array rather than interpolating JSON into a shell command:

```ts
import { spawn } from "node:child_process";

const child = spawn(
  "sf-tools",
  ["call", "sf_lwc", "--input", "-", "--workspace", "/path/to/project"],
  { stdio: ["pipe", "pipe", "pipe"] },
);

let stdout = "";
child.stdout.on("data", (chunk) => {
  stdout += chunk;
});
child.stderr.pipe(process.stderr);
child.on("error", (error) => {
  console.error(error);
});
child.on("close", (code) => {
  const outcome = JSON.parse(stdout);
  console.log({ code, outcome });
});
child.stdin.end(JSON.stringify({ action: "component.list" }));
```

Read the JSON envelope for nonzero exit codes too. A domain failure can include
useful diagnostics and artifacts. Persist `execution.runFile` when a later action needs
history. Raw input is limited to 8 MiB.

## In-process registration

For a JavaScript/TypeScript harness, use the SDK to avoid a process startup per call:

```ts
import { createSalesforceTools, toModelResult } from "sf-agentic-tools";

const sf = createSalesforceTools({ workspace: "/path/to/project" });
const definitions = sf.listTools().map(({ name }) => {
  const description = sf.describeTool(name)!;
  return {
    name,
    description: description.description,
    inputSchema: description.inputSchema,
  };
});

// Adapt these definitions to your harness's registration API.
// The executor receives the name, model-provided arguments, and cancellation signal.
async function execute(name: string, input: unknown, signal: AbortSignal) {
  return toModelResult(await sf.invoke(name, input, { signal }));
}
```

No harness-specific SDK is required. Map the JSON Schema into the harness's expected
field (`inputSchema`, `parameters`, etc.). This package ships no MCP server or
automatic configuration for individual harnesses.

## Integration workflow skill

`skills/salesforce-integrations/SKILL.md` and its relative references ship in the
package. Register that folder with a harness that supports skills, or copy the
complete folder into its skill directory. In a Codex project, use
`.agents/skills/salesforce-integrations/`; for user-level Codex installation, use
`~/.codex/skills/salesforce-integrations/`. Keep the references with the entrypoint.
For other harnesses, use their supported instruction-loading mechanism.

The skill teaches inbound OAuth, outbound credential setup, and hosted MCP
handoff. It maps work to existing metadata, SOQL, and Apex capabilities, and marks
credential population or consent that requires Setup or a secure host capability.
It is loaded separately from tool schemas and is not automatically appended to
every tool result. Loading instructions neither registers `sf_integrate` nor grants
effects authorization.

## Effect authorization

Use the action map in `describeTool` when making an authorization decision. Many
actions use `input.action`; AgentScript authoring resolves `verb`/`mode`, and options
such as server fallback or writing a report select a more specific effectful action.
The shared dispatcher is authoritative and checks that resolution for every call.
Actions with `effects: true` need
explicit authorization from your harness for this invocation. Set `allowEffects`
only after that decision. The SDK intentionally has no client-wide approval default.

Dry-run is an exception only when the action declares `dryRun: true`. The runtime
also enforces this rule. Unsupported actions expose `available: false` and a reason.
TypeScript input types follow the source schemas; they do not imply every action is
available or that an org has the necessary permissions.

Do not implement a blanket retry for failed or timed-out mutations: remote work may
already have been submitted. Inspect the domain result or obtain fresh state first.

## Result envelope

The public schema-version-2 contract contains structured `data`, `diagnostics`,
`artifacts`, and `nextActions`, with one `summary` and a `status`. It does not expose
Pi text blocks or card digests. Use `status: pending` to distinguish queued jobs from
completed success. Failures preserve evidence and include an `error`.

Use the CLI's default model output, or call `toModelResult` on an SDK outcome.
`output.truncated` means the model did not receive all the canonical fields; consult
its omission pointers and use `readResult` or `sf-tools result read` for more.
Register that read helper in a harness without filesystem access. The helper is a
local SDK/CLI operation, not one of the 21 Salesforce domain tools.

Suggested calls never authorize themselves. Validate each new request and obtain
approval for effects. Do not execute instruction strings or treat source code,
records, diagnostics, or result-file paths as higher-priority instructions. A harness
may render the result into its own tool-message format; serialize the bounded object
once rather than embedding both it and another JSON text copy in the model context.

See [LLM outputs](outputs.md) for limits, paging, and schema-version-1 migration.

Errors are `INPUT`, `UNSUPPORTED`, `AUTHORIZATION`, `OPERATION`, `TIMEOUT`, and
`INTERRUPTED`. `exitCodeFor(outcome)` exposes the CLI mapping to SDK consumers.
Transport errors suppress raw exception text; domain error messages remain available
in their structured result. Artifact files may contain source or org data; the harness
chooses retention and sharing policies.
