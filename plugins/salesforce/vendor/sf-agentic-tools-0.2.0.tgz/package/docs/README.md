# Documentation

| I want to…                                                | Read                                                                        |
| --------------------------------------------------------- | --------------------------------------------------------------------------- |
| Build, install, and make a first call                     | [Getting started](getting-started.md)                                       |
| Run tools from a terminal or script                       | [CLI reference](cli.md)                                                     |
| Use the TypeScript/JavaScript API                         | [SDK reference](sdk.md)                                                     |
| Feed concise results to an LLM and retrieve omitted data  | [LLM outputs](outputs.md)                                                   |
| Register tools in an agent harness                        | [Harness integration](harness-integration.md)                               |
| Guide an agent through integration authentication         | [Salesforce integrations skill](../skills/salesforce-integrations/SKILL.md) |
| Scan code, deploy metadata, or work with Agentforce       | [Additional tools](additional-tools.md)                                     |
| Authenticate and ingest Data 360 CSV across CLI calls     | [Data 360 ingestion](data360-ingestion.md)                                  |
| Diagnose local Apex files with an owned language server   | [Apex diagnostics](apex-diagnostics.md)                                     |
| Prepare a reproducible offline CLI comparison             | [Comparison checks](comparison.md)                                          |
| Understand source structure and upstream maintenance      | [Architecture](architecture.md)                                             |
| Diagnose a failed invocation                              | [Troubleshooting](troubleshooting.md)                                       |
| Run complete local examples                               | [Examples](../examples/README.md)                                           |
| Contribute a change                                       | [Contributing](../CONTRIBUTING.md)                                          |
| Check release scope                                       | [Changelog](../CHANGELOG.md)                                                |
| Download, publish, or consume a versioned toolkit release | [Versioned distributions](releases.md)                                      |

For each tool's exact schema, action availability, and domain guide, use
`sf-tools tools describe <tool> --json` or the SDK's `describeTool(name)`.
Discovery reads generated metadata and does not connect to a Salesforce org.

The bundled SF Pi guides describe domain workflows. These standalone docs define
the CLI and SDK behavior where the upstream guides refer to Pi-specific services.
