# TypeScript SDK reference

Import from `sf-agentic-tools` in an ESM JavaScript or TypeScript application.
The SDK uses the same execution contract as the CLI and calls the domains directly.

## Create a client

```ts
import { createSalesforceTools } from "sf-agentic-tools";

const sf = createSalesforceTools({
  workspace: "/path/to/project",
  artifactDir: "/path/to/runs",
  timeoutMs: 120000,
  targetOrg: "sandbox",
});

const outcome = await sf.flow({ action: "quality.rules" });
if (outcome.ok) {
  console.log(outcome.data, outcome.execution.runFile);
} else {
  console.error(outcome.error.code, outcome.error.message);
}
```

All client options are optional. `workspace` defaults to the current directory when
the client is created; artifacts default to a temporary root; timeout defaults to
120000 ms. `targetOrg` supplies the default `target_org` input. A non-null per-call
`target_org` takes precedence. When neither value is supplied, org operations use
Salesforce's configured target for the original core/Data 360 tools. Metadata and
remote AgentScript operations and Data 360 ingestion sessions require an explicit
target from input or the client. See [Data 360 ingestion](data360-ingestion.md),
including the per-call `onAuthorization` callback for interactive OAuth.

There is deliberately no client-wide `allowEffects` default. Authorization belongs
to an individual invocation.

## Public functions and methods

| API                                                                         | Purpose                                                                  |
| --------------------------------------------------------------------------- | ------------------------------------------------------------------------ |
| `createSalesforceTools(defaults?)`                                          | Create a client with workspace, artifact, timeout, and org defaults      |
| `sf.call(name, input, options?)`                                            | Invoke a known tool with TypeScript input checking                       |
| `sf.invoke(name, input, options?)`                                          | Invoke a dynamic name and `unknown` input received from a model          |
| `sf.soql`, `sf.apex`, `sf.lwc`, `sf.flow`                                   | Typed convenience methods for the four core families                     |
| `sf.codeAnalyzer`, `sf.metadata`                                            | Code quality and general metadata workflows                              |
| `sf.agentAuthoring`, `sf.agentPreview`, `sf.agentEval`, `sf.agentLifecycle` | AgentScript and Agentforce workflows                                     |
| `callTool(name, input, options?)`                                           | Typed invocation without creating a client                               |
| `executeTool(name, input, options?)`                                        | Dynamic invocation without creating a client                             |
| `resetSalesforceConnections()`                                              | Clear cached org resolution, aliases, and configuration for future calls |
| `listTools()` / `sf.listTools()`                                            | Return compact tool summaries                                            |
| `describeTool(name)` / `sf.describeTool(name)`                              | Return a schema and capability description, or `undefined`               |
| `exitCodeFor(outcome)`                                                      | Map an outcome to the CLI exit code                                      |
| `exitCodes`                                                                 | Read-only error-code-to-exit-code mapping                                |

Data 360 families use `call` directly:

```ts
await sf.call("data360_query", {
  action: "action.describe",
  params: { action: "sql.run" },
  output_mode: "inline",
});
```

Tool names, input field types, and action names are checked at compile time. The
generated Data 360 action unions are specific to each family. Nested Data 360
`params` remain `Record<string, unknown>` and require action-specific runtime
validation. Input types follow the upstream schemas; consult `describeTool` for
availability and `action.describe` for Data 360's per-action requirements.

## Per-call options

| Option            | Type                               | Purpose                                                |
| ----------------- | ---------------------------------- | ------------------------------------------------------ |
| `workspace`       | `string`                           | Override the client's workspace                        |
| `artifactDir`     | `string`                           | Override the artifact root                             |
| `timeoutMs`       | `number`                           | Integer timeout from 1 through 3600000                 |
| `allowEffects`    | `boolean`                          | Authorize effects for this call                        |
| `resume`          | `string`                           | Prior `runFile` with matching tool/workspace/org scope |
| `signal`          | `AbortSignal`                      | Cancel the invocation                                  |
| `onAuthorization` | `(event) => void \| Promise<void>` | Present an interactive Data 360 OAuth URL in your host |

An effectful action still needs its domain intent flags and prerequisites after
`allowEffects` is set. An unrelated `dry_run: true` field cannot bypass authorization;
the action must declare dry-run support.

Options are validated before loading a tool. Paths must be nonempty strings,
`allowEffects` must be a boolean, and `signal` must be an `AbortSignal`. Resume files
must be at most 100 MiB and match the original tool, workspace, and org scope.

## Results and errors

`call` returns `Promise<CallOutcome<Name>>` with `schemaVersion: 2`. Read `data`
for domain fields, `diagnostics` for findings, `artifacts` for evidence paths, and
`nextActions` for follow-up suggestions. `status` distinguishes `success`, `warning`,
`pending`, and `error`. `ok: true` can mean that a remote job was submitted and is
still pending. Failed calls expose `error.code`, `error.message`, and sometimes
`error.domainCode`; partial data and diagnostics remain available.

```ts
import { toModelResult, readResult } from "sf-agentic-tools";

const result = await sf.lwc({
  action: "component.inspect",
  component: "helloWorld",
});
if (result.ok) {
  console.log(result.data.inspection?.bundle.name);
  console.log(result.execution.runFile, result.execution.resultFile);
} else {
  console.error(result.error.message, result.diagnostics);
}

// Give this bounded JSON object to the model, using your harness's tool message API.
const modelResult = toModelResult(result, { maxBytes: 24000 });

// Read a field later without rerunning Salesforce operations.
if (result.execution) {
  const page = await readResult(result.execution.resultFile, {
    pointer: "/diagnostics",
    offset: 0,
    limit: 10,
  });
  console.log(page.data.value);
}
```

The SDK returns the complete normalized domain result; `toModelResult` produces a
separate, potentially partial `ModelOutcome` and does not mutate that result.
`readResult` returns a bounded page and throws `ToolExecutionError` for invalid files
or selections. Invalid projection options throw `RangeError`; validate them before
starting an effectful call if the harness accepts user-supplied output settings.

Public types include `SalesforceTools`, `ClientOptions`, `CallOptions`, `ToolName`,
`ToolInput<Name>`, `ToolInputs`, `CallOutcome<Name>`, `ToolData<Name>`, `Diagnostic`,
`NextAction`, `Artifact`, `ExecutionInfo`, `ModelOutcome`, `ModelOutputOptions`,
`ReadResultOptions`, and `ToolError`. Common fields are typed for SOQL, LWC, metadata,
Code Analyzer, and AgentScript; action-specific extension fields and Data 360 data
remain `unknown` and require narrowing. This is not a complete schema for every
Salesforce API response. `resultSchema` and `describeTool(name).outputSchema`
describe the shared JSON contract.

Input types include `SoqlInput`, `ApexInput`, `LwcInput`, `FlowInput`,
`Data360Input<Name>`, `CodeAnalyzerInput`, `MetadataInput`, and the four AgentScript
input types. Authoring uses `verb`/`mode` instead of `action`.

See [LLM outputs and migration](outputs.md) for field mappings, limits, and paging.

## Cancellation and concurrency

Pass a signal owned by your harness:

```ts
const controller = new AbortController();
const pending = sf.lwc(
  { action: "project.scan" },
  { signal: controller.signal },
);

// When the harness cancels its task:
controller.abort();
const outcome = await pending;
```

Cancellation returns `INTERRUPTED`; the invocation timeout returns `TIMEOUT`.
Cancellation is cooperative and does not undo work already submitted remotely.

Calls can run concurrently. Each gets separate state, a run ID, and an artifact
directory. Source mutations are serialized per canonical file within the process.
The SDK does not change the working directory, attach process signal listeners, or
redirect host logging. Explicit `resume` carries invocation state into another call.
Agentforce preview/evaluation also use explicit identifiers and durable project
artifacts; those domain stores do not require a Pi session or implicit conversation.
Keep calls to the same preview session sequential.

Connections cache org resolution. After changing Salesforce CLI authentication,
aliases, or target configuration, reset the caches before starting further calls:

```ts
import { resetSalesforceConnections } from "sf-agentic-tools";

await resetSalesforceConnections();
```

The reset applies across clients in the process. It clears in-memory configuration,
alias, and connection caches without selecting or contacting an org. Existing
sessions keep their resolved org identity; subsequent connections reload local
configuration and authentication.

See [examples](../examples/README.md) for runnable code and
[harness integration](harness-integration.md) for dynamic registration.
