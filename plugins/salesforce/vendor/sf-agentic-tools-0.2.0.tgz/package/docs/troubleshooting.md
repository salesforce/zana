# Troubleshooting

Start by retaining the result JSON, exit code, and any `execution.runFile` path. Use
`sf-tools tools describe <tool> --json` to check the exact contract for the installed
version before changing inputs.

| Symptom                               | What to check                                                                                                                                                            |
| ------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| `sf-tools` is not found               | Install the tarball globally, or run `node dist/cli.js` from a built checkout.                                                                                           |
| `dist` or package exports are missing | Run `npm ci` and `npm run build` in the source checkout.                                                                                                                 |
| ESM/import syntax errors              | Check Node is at least 22.19 and use an ESM consumer. The package exposes an ESM import entry point.                                                                     |
| `INPUT` / exit 2                      | Check JSON syntax, `action`, field types, exactly one input source, workspace existence, timeout bounds, and resume scope.                                               |
| `UNSUPPORTED` / exit 3                | Check the tool name and the action's `available` / `reason` fields. A known tool can contain unsupported actions.                                                        |
| `AUTHORIZATION` / exit 4              | Review the action's effects. Use per-call authorization only after the harness has obtained the required approval. SOQL locking/tracking execution is unavailable.       |
| `OPERATION` / exit 5                  | Read `error`, `diagnostics`, and `data`; use `execution.resultFile` for omitted evidence. Check domain prerequisites, permissions, paths, and artifact-root writability. |
| Missing org or expired authentication | Use the normal Salesforce CLI authentication workflow, then pass the intended `target_org` explicitly.                                                                   |
| LWC tests cannot start                | Check the selected SFDX project contains the intended tests and the required local LWC Jest runner.                                                                      |
| Resume is rejected                    | Match the tool, canonical workspace, tool-specific workspace input, and org. Non-LWC resumes require explicit `target_org` on both calls.                                |
| Flow quick fix is stale               | Run `diagnose.file` again and use its current `fix_id` and `source_version`.                                                                                             |
| Data 360 result looks abbreviated     | Summary output can point to a full JSON artifact. Use `output_mode: "inline"` when the complete result is appropriate.                                                   |
| `TIMEOUT` or `INTERRUPTED`            | Inspect current state before retrying remote effects; work already submitted can continue.                                                                               |

## Distinguish the two executables

`sf` is the Salesforce CLI used for authentication and other Salesforce workflows.
`sf-tools` is this package's tool runner. `target_org` belongs inside a tool's JSON
input; `sf-tools` does not have a `--target-org` option.

## Keep useful evidence

When reporting a problem, include the package and Node versions, tool/action,
redacted input, exit/error code, whether it reproduces locally without an org,
and the relevant result details. Do not paste authentication material or unreviewed
org data from artifacts into an issue.

```sh
node --version
sf-tools --version
sf-tools tools describe sf_lwc --json
```

Transport failures intentionally use a bounded message. Domain results and saved
artifacts often contain the more specific explanation. Not every early failure
creates a run directory.
