# Data 360 ingestion authentication

Tenant ingestion uses a Data 360 token and tenant host, separate from ordinary
Salesforce REST authentication. The authentication and ingestion actions work
across independent CLI calls, SDK clients, and the three Data 360 families.
The two-stage token exchange follows the
[Salesforce Ingestion API authentication guide](https://developer.salesforce.com/docs/data/data-cloud-int/references/data-cloud-ingestionapi-ref/c360-a-api-get-started.html).

Select the same workspace and explicit `target_org` for every call. Authentication
is scoped to that workspace and target label; no configured org is selected for
this workflow. The OAuth login determines the identity and tenant. Job requests
use the host saved by the token exchange, regardless of any `tenantHost` input.

1. Call `data360_connect` / `auth.pkce_start` with your OAuth client settings.
2. Open the returned `data.authorization.url` through your harness/browser.
3. Obtain the authorization code and matching state from your configured redirect.
4. Call `auth.exchange` with `pkceState` and `authorizationCode`.
5. Pass the returned `data.authSession.id` as `authSessionId` to ingestion actions.

```sh
sf-tools call data360_connect --workspace /path/to/project --allow-effects \
  --input '{"action":"auth.pkce_start","target_org":"sandbox","params":{"loginUrl":"https://test.salesforce.com","clientId":"YOUR_OAUTH_CLIENT_ID","redirectUri":"http://127.0.0.1:1717/oauth"}}'

# Supply the authorization code privately through stdin or a private input file.
sf-tools call data360_connect --workspace /path/to/project --allow-effects --input -
```

The exchange JSON is:

```json
{
  "action": "auth.exchange",
  "target_org": "sandbox",
  "allow_confirmed": true,
  "params": {
    "pkceState": "STATE_FROM_START",
    "authorizationCode": "CODE_FROM_REDIRECT"
  }
}
```

The alternative explicit exchange inputs (`loginUrl`, `clientId`, `redirectUri`,
`codeVerifier`, `authorizationCode`, optionally `strategy: "pkce"`) remain supported.
Only PKCE exchange is implemented; other strategies have planning guidance.
Do not pass secrets through shell command arguments if your host records them.

Use `data360_prepare` actions `ingest_job.create`, `ingest_job.upload_csv`,
`ingest_job.close`, and `ingest_job.poll`. Their `tenant_ingest.job.*` aliases also
work. Mutations require both per-call effects authorization and
`allow_confirmed: true`; `dry_run: true` plans the request without sending it.
Pass `sourceName` and `object` when creating a job, and the actual returned `jobId`
for upload, close and polling. Upload `csvPath` is relative to the workspace,
must resolve inside it, and is limited to 50 MiB. HTTP responses are limited to
1 MiB and each request has a 30-second bound plus the invocation timeout/signal.

`auth.sessions` lists sanitized metadata; `auth.status` checks current scoped
sessions (optionally one `authSessionId`). `auth.clear` requires effects
authorization and deletes one identifier or all token/pending PKCE records in the
scope. Its dry run does not delete files. Existing upstream aliases are retained.

Credentials are stored in private directories (0700) and files (0600) under
`.sf-agentic-tools/state/data360/`. These are local credential files, not encrypted
vault entries. They are never included in public results or invocation run files.
Add `.sf-agentic-tools/` to your project's `.gitignore`. PKCE states expire after
ten minutes and are consumed once. Tokens use their provider expiry, capped at
24 hours; missing expiry defaults to one hour. Expired token files are removed
when read. Expired pending PKCE records are removed when used or by `auth.clear`.
Keep a scope on the same machine/filesystem when switching harnesses.

For automatic localhost callback handling, use `data360_orchestrate` /
`ingest_auth.pkce_interactive`. It requires a registered HTTP redirect URI on
`localhost` or `127.0.0.1`, fresh effects authorization and `allow_confirmed: true`.
The CLI prints the authorization URL on stderr while keeping one JSON result on
stdout. The SDK requires an `onAuthorization` callback:

```ts
const result = await sf.call(
  "data360_orchestrate",
  {
    action: "ingest_auth.pkce_interactive",
    target_org: "sandbox",
    allow_confirmed: true,
    params: {
      loginUrl: "https://test.salesforce.com",
      clientId: "YOUR_OAUTH_CLIENT_ID",
      redirectUri: "http://127.0.0.1:1717/oauth",
    },
  },
  {
    allowEffects: true,
    timeoutMs: 300000,
    onAuthorization: ({ authorizationUrl }) => {
      // Present this URL in your host's UI/browser.
      console.error(authorizationUrl);
    },
  },
);
```

The tool never launches a browser. The listener closes on success, failure,
timeout or cancellation. Local authentication artifacts are cleaned up even when
the invocation is aborted. Live Data 360 behavior has not been verified against
an org; the persistence, routing and failure cases have offline integration tests.
