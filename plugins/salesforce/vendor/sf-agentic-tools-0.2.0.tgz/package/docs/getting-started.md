# Getting started

## 1. Build from this checkout

Node.js 22.19 or newer is required. The package contains ESM JavaScript and
TypeScript declarations.

```sh
npm ci
npm run build
node dist/cli.js --version
node dist/cli.js tools list --json
```

The version command reports `0.2.0`; discovery returns 21 tool names. You do not need
Salesforce credentials for either command.

## 2. Make a local call

```sh
node dist/cli.js call sf_flow --input-file examples/flow-quality.json
node examples/local-tools.mjs
```

The CLI example returns the Flow quality-rule catalog. The SDK example runs local
operations in Flow, Apex, and Data 360 and prints one summary per result. Neither
example selects an org or changes remote state.

Successful calls include `ok: true`, `status`, `data`, and an `execution.runFile` path.
The CLI and example use a bounded model view; omitted data remains in
`execution.resultFile`. See [LLM outputs](outputs.md) for paging. Artifacts default
to the system temporary directory. Set `--artifact-dir /path/to/runs` or the SDK's
`artifactDir` when you want to keep them in a known location.

## 3. Install the CLI or SDK

Download and verify a pinned tarball using [Versioned distributions](releases.md).
For a development tarball built from this checkout instead:

```sh
npm pack
```

For a global CLI installation:

```sh
npm install --global ./sf-agentic-tools-0.2.0.tgz
sf-tools tools list --json
```

For an application using the SDK, run this from that application's directory:

```sh
npm install /path/to/sf-agentic-tools-0.2.0.tgz
```

Import the package from an ESM JavaScript file or a TypeScript project configured
for ESM. The [SDK reference](sdk.md) shows the public methods and types.

## 4. Point local tools at an SFDX project

Replace `/path/to/project` with the project directory containing `sfdx-project.json`:

```sh
sf-tools call sf_lwc --input '{"action":"component.list"}' --workspace /path/to/project
sf-tools call sf_flow --input '{"action":"project.scan"}' --workspace /path/to/project
```

The workspace option supplies the tools' working context. It does not change the
calling process's working directory or provide an operating-system sandbox.

## 5. Connect org operations

The package reuses local Salesforce authentication. The `sf` Salesforce CLI and
this package's `sf-tools` executable are separate commands. If the target is already
authenticated, pass its alias in `target_org`.

Otherwise, authenticate through your normal Salesforce CLI workflow. For example,
replace the sample hostname with your sandbox's My Domain hostname:

```sh
sf org login web --alias sandbox --instance-url https://example--dev.sandbox.my.salesforce.com
```

Once login completes, run a bounded query against that explicit alias:

```sh
sf-tools call sf_soql --input '{"action":"query.run","target_org":"sandbox","query":"SELECT Id, Name FROM Account LIMIT 5","max_rows":5}' --workspace /path/to/project
```

Your org permissions determine which records and operations are available. The same
target can be supplied as `targetOrg` when constructing an SDK client, then overridden
per call with `target_org`.

Live Salesforce workflows are not part of this extraction's offline verification.
For effects such as test execution or source fixes, inspect the action metadata and
follow the per-call authorization contract in the [CLI](cli.md) or [SDK](sdk.md) reference.

## Next steps

- [CLI reference](cli.md): options, JSON input, exit codes, and resume.
- [SDK reference](sdk.md): typed inputs, dynamic calls, cancellation, and results.
- [Harness integration](harness-integration.md): discovery and execution adapters.
- [Troubleshooting](troubleshooting.md): failures, prerequisites, and artifacts.
