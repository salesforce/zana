<!-- SPDX-License-Identifier: Apache-2.0 -->

# Inbound Salesforce OAuth

Use an External Client App (ECA) when an application needs authenticated access to
Salesforce. Choose the flow from the client's capabilities and identity needs.
These profiles summarize the reviewed SF Integrate workflows; confirm current
metadata support and security policy in the target org before authoring source.

| Flow                                | Inputs and prerequisites                                                                                                                                                         | Verification                                                           |
| ----------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ---------------------------------------------------------------------- |
| Confidential Authorization Code     | Actual client callback, scopes, secure server-side consumer-secret custody, PKCE                                                                                                 | Code exchange by the intended client and refresh behavior if requested |
| Public Authorization Code with PKCE | Actual client callback, scopes, PKCE; no embedded consumer secret                                                                                                                | Code exchange using the matching verifier                              |
| Client Credentials                  | Explicit execution user with required API access and API Only configuration; secure client-secret custody                                                                        | Token exchange and a bounded API request as that user                  |
| Device                              | Client support for device authorization and an appropriate localhost callback; keep separate from other flows in the reviewed profile                                            | Device authorization completed by the user, then a bounded API request |
| JWT Bearer                          | PEM public certificate, matching private key held by the external client, subject user, existing assigned pre-authorization Permission Set                                       | Signed assertion exchange and a bounded API request                    |
| Token Exchange                      | Existing Apex class extending `Auth.Oauth2TokenExchangeHandler`, active execution user, assigned pre-authorization Permission Set, handler binding and matching app/policy flags | Exchange of the intended subject-token type and a bounded API request  |

## Prepare the resource graph

The reviewed profiles use these core metadata components:

- `ExternalClientApplication`
- `ExtlClntAppGlobalOauthSettings`
- `ExtlClntAppOauthSettings`
- `ExtlClntAppOauthConfigurablePolicies`

Token Exchange also uses `OauthTokenExchangeHandler` to bind the existing Apex
handler to the app. Inspect that class and its prerequisites; do not invent or
replace its validation logic as a side effect of authentication setup.

Use supported metadata types and field names for the target API version. Verify
the callback, metadata scope names, PKCE and consumer-secret policies, flow flags,
permitted users, execution user, certificate presence, and handler binding as
applicable. Request only scopes the integration needs. OAuth request scope strings
and Metadata API scope identifiers are different representations.

For a public certificate input, resolve the path inside the workspace and check
that it contains a PEM certificate rather than a private key. Keep the signing key
with the external client. Do not collect it through chat or package inputs.

Preview and check-only validate the reviewed source before an authorized deploy.
Follow the deployment job, inspect non-sensitive readback, and then test the actual
client handshake. Do not infer successful authentication from deployment success.
Salesforce-generated consumer-secret custody is a separate secure step; a client
credentials plan cannot demonstrate token exchange until that step is complete.

## Readback boundaries

Inspect public configuration and certificate presence without collecting consumer
secrets. In particular, global OAuth settings may expose sensitive material. If
the available readback tool cannot safely select fields, use Setup inspection and
report that verification boundary rather than storing a raw retrieval.

Check the target's metadata availability instead of assuming every org type or
API version supports direct ECA creation. For hosted MCP, follow the separate
[hosted-MCP reference](hosted-mcp.md), including its scratch-org caveat.

## Official references

- [Global OAuth metadata](https://developer.salesforce.com/docs/atlas.en-us.api_meta.meta/api_meta/meta_extlclntappglobaloauthsettings.htm)
- [Org-local OAuth policies](https://developer.salesforce.com/docs/atlas.en-us.api_meta.meta/api_meta/meta_extlclntappoauthconfigurablepolicies.htm)

Derived and adapted from the pinned upstream guides cited in `../SKILL.md`.
