<!-- SPDX-License-Identifier: Apache-2.0 -->

# Outbound authenticated callouts

Use modern External Credentials and Named Credentials when Salesforce calls an
external service. The Named Credential holds the endpoint and references the
External Credential's authentication configuration. Principal access and user
assignment are part of the integration, not optional verification details.

| Authentication                              | Required plan inputs                                                                                                 | Post-creation work                                               |
| ------------------------------------------- | -------------------------------------------------------------------------------------------------------------------- | ---------------------------------------------------------------- |
| OAuth Client Credentials with client secret | HTTPS endpoint, token URL, public client ID, scopes, named principal                                                 | Securely populate the client secret                              |
| OAuth JWT Bearer                            | HTTPS endpoint, token URL, existing Salesforce signing certificate, literal issuer/subject/audience, named principal | Verify certificate binding; no separate client-secret population |
| Browser Authorization Code                  | HTTPS endpoint, authorization/token URLs, External Auth Identity Provider, principal model                           | Secure provider credential population, then user consent         |
| API-key header                              | HTTPS endpoint, header name, custom credential parameter, named principal                                            | Securely populate the key                                        |

The reviewed browser workflow defaults to a per-user principal; the other listed
profiles use a named principal. Make that choice explicit because it determines
which identity authenticates and who must complete consent.

## Prepare and configure

Plan the required subset of this graph:

```text
External Auth Identity Provider (when needed)
  → External Credential + principal
  → Named Credential + service endpoint
  → Permission Set granting that principal's access
  → assignment to the intended Salesforce user(s)
```

Inspect existing names and assignments first. Author deployable metadata using
the target API's supported types and fields. Preview, check-only validate, deploy
with authorization, and follow the job to completion. The metadata model does not
carry every runtime credential value: use Setup or a verified secure Connect REST
capability for the remaining operations.

Metadata deployment alone cannot populate all sensitive credentials. Salesforce's
[credential population guide](https://developer.salesforce.com/docs/platform/named-credentials/guide/nc-populate-external-credentials.html)
describes the separate secure configuration step. Resolve secrets only inside that
path. Neither `sf_metadata` nor a secret embedded in `sf_apex` input supplies secure
population. If no suitable host capability exists, give the operator the credential
and principal names to configure in Setup; never ask for the values in chat.

For browser OAuth, verify the provider configuration and principal access before
consent. Each user must authenticate for a per-user principal. An authorization URL
is evidence that consent can begin, not evidence of completed consent. Keep
provider metadata creation and credential population in separate transactions
where the chosen API requires it; see Salesforce's
[OAuth Named Credential example](https://developer.salesforce.com/docs/platform/named-credentials/guide/nc-create-oauth-cred.html).

## Verify and test

Verify the endpoint, credential link, auth protocol, principal identity, principal
access, user assignments, certificate/provider linkage, and available configured
or authenticated status. Then test as the intended Salesforce user.

For a connection probe, use one bounded GET via `sf_apex` action `anon.run`, an
explicit `target_org`, and per-call effects authorization. Use
`callout:<NamedCredential>/<relative-path>`, not an absolute URL or a different
credential. Choose an endpoint known to be read-only. Set a short timeout and
assert the expected HTTP status. Keep credentials out of the Apex body, and do not
print response bodies or authentication headers. `allow_mutation: false` does not
remove the runtime's effects requirement for Anonymous Apex.

Inspect both the v2 outcome and Apex compilation/execution evidence. A probe that
catches and logs an exception without failing can appear successful; assert the
required status or propagate failure. Report only the bounded callout's result,
not broad assurance that all service operations work.

After a failure, inspect existing resources before repair. Check endpoint/token
URLs, provider client-authentication expectations, scope, principal access and
consent state. Do not automatically rotate secrets, replace credentials, or delete
partially created resources.

Derived and adapted from the pinned upstream guides cited in `../SKILL.md`.
