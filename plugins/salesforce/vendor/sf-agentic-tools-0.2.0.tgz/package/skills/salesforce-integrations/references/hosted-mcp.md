<!-- SPDX-License-Identifier: Apache-2.0 -->

# Salesforce hosted MCP OAuth

Prepare the Salesforce-org side of OAuth; the calling harness owns MCP server
configuration, transport, login, token custody, and tool exposure. This package
does not install an MCP server or configure the client.

## Establish the actual client's requirements

Read the client's current OAuth configuration or official documentation for its
callback URL and supported client authentication. Do not assume a localhost port
from another harness. Select the hosted server from Salesforce's current
documentation and the user's org context; do not reuse a private environment URL.

Salesforce's [hosted-MCP ECA guide](https://developer.salesforce.com/docs/platform/hosted-mcp-servers/guide/create-external-client-app.html)
requires an External Client App and documents callbacks that vary by client.
Confirm its current requirements before configuring:

- OAuth request scopes `mcp_api` and `refresh_token`; the reviewed metadata uses
  the identifiers `MCP` and `RefreshToken`.
- JWT-based access tokens for named users.
- Consumer-secret policy compatible with the client. The reviewed upstream
  desktop profile is public; do not carry that assumption into a confidential
  web client that securely stores a secret.
- PKCE support and the intended refresh-token policy. The upstream public profile
  uses PKCE and rotation; check current Salesforce and client requirements rather
  than copying its flags unchanged.

The official guide also notes that ECA creation through Setup is unavailable
directly in scratch orgs; its documented route is creation in a developer hub,
packaging, and installation. Do not treat that Setup limitation as proof about all
Metadata API paths. Confirm the target's supported creation mechanism.

## Configure, hand off, and prove

1. Follow the inbound planning workflow with an explicit non-production target,
   exact resource names, actual callback, scopes, and client profile. Bind the plan
   to the resolved org id and My Domain, not only to an alias.
2. Inspect for an existing External Client App first. Adopt one only when its
   non-sensitive settings exactly match the plan (scopes, callback, JWT, PKCE,
   secret and refresh policy); adoption makes no changes to it. A mismatched or
   newly appeared app is drift: report it and require a separately scoped change
   plan rather than overwriting it.
3. Otherwise create the app through the supported, authorized metadata or Setup
   path, validating metadata first, and verify non-sensitive readback. An ECA may
   take time to become operational; Salesforce documents a possible delay of up
   to 30 minutes. Inspect before recreating it.
4. Confirm the hosted server is activated for the org. Upstream observed a Tooling
   `McpServerAccess` object for this, but it is not a documented public contract.
   Describe it with `sf_soql` `schema.describe` and `api: "tooling"` and read
   current state with a bounded query before relying on it. This package has no
   generic Tooling write; when activation is needed, or schema, permissions, or
   rows are missing or ambiguous, give the operator the Setup task, then read
   back the resulting state. Do not claim activation from intent alone.
5. Hand off only the public consumer key/client ID, the bound org id and My Domain,
   the hosted server and its activation state, callback, and requested scopes.
   Use a deterministic per-org client connection name so several orgs do not
   overwrite one another. Refer to Setup by page name, not a session-bearing URL.
   Configure the harness's supported MCP settings only when that is part of the
   user's request.
6. Complete login using the harness's native OAuth mechanism. Prove the intended
   server connection with one bounded read capability, and confirm the
   authenticated organization id equals the bound org id, without exposing tokens.

Report org-side configuration and client-side connection separately. A consumer
key proves app identity; it does not prove activation, login, org binding, or tool
discovery. Use the client's own token store and avoid storing tokens in package
artifacts or source.

Derived and adapted from the pinned upstream guides cited in `../SKILL.md`.
