# Examples

From a source checkout, run `npm ci` and `npm run build` first. These examples use
local catalog and authoring operations, require no org, and do not authorize effects.

## JSON CLI input

```sh
node dist/cli.js call sf_flow --input-file examples/flow-quality.json
```

[flow-quality.json](flow-quality.json) requests the Flow rules for the review profile.
The command prints the regular JSON result envelope.

## In-process SDK

```sh
node examples/local-tools.mjs
```

[local-tools.mjs](local-tools.mjs) imports the package by name and runs Flow quality
discovery, local Apex authoring, and Data 360 action discovery. It prints compact
summaries and returns a nonzero exit code if a call fails. Optionally supply an
existing workspace directory as the first argument.

The example is also included in the tarball. From a project that installed the package:

```sh
node node_modules/sf-agentic-tools/examples/local-tools.mjs
```

See the [SDK reference](../docs/sdk.md) for TypeScript examples with typed results,
and [harness integration](../docs/harness-integration.md) for a registration adapter.
