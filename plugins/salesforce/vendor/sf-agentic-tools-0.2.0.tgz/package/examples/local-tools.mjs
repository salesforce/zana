/* SPDX-License-Identifier: Apache-2.0 */
import {
  createSalesforceTools,
  exitCodeFor,
  toModelResult,
} from "sf-agentic-tools";

const sf = createSalesforceTools({
  workspace: process.argv[2] ?? process.cwd(),
});

const outcomes = [
  await sf.flow({ action: "quality.rules", quality_profile: "review" }),
  await sf.apex({ action: "author.plan", intent: "Create a focused service" }),
  await sf.call("data360_query", {
    action: "action.describe",
    params: { action: "sql.run" },
    output_mode: "inline",
  }),
];

for (const outcome of outcomes) {
  console.log(JSON.stringify(toModelResult(outcome)));
}

const failure = outcomes.find((outcome) => !outcome.ok);
process.exitCode = failure ? exitCodeFor(failure) : 0;
