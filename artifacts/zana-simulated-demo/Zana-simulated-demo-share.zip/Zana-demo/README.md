# Zana — a simulated walkthrough

Play Zana-simulated-demo.mp4, or open watch.html for chapter navigation.

For the interactive version, open demo/index.html in a desktop browser. Press Play and turn Sound on to hear the narration. The Try the plugin button lets you use the Focus Board's checkboxes and add-task control. Everything runs offline; no account or installation is required. Unzip this package before opening the HTML files.

This is a 3:10 scripted replica with fictional projects, agents, tickets, outputs, and plugin installation. It demonstrates creating a project, launching and monitoring an agent, viewing GUS work, and making a custom plugin. The simulated test results shown on screen belong to the story. Interactive plugin changes stay in the current demo tab.

The video is 1920 × 1080 at 24 fps, with English narration and captions in the picture. Captions and a transcript are also included as separate files. All cursor motion is drawn inside the replica; the demo does not control your desktop.
